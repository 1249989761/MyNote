#include <stdio.h>

// #include "test_func/testFunc.h"
// #include "test_func1/testFunc1.h"

#include "testFunc.h"
#include "testFunc1.h"

int main(void)
{
    func(100);
    func1(200);

    return 0;
}
