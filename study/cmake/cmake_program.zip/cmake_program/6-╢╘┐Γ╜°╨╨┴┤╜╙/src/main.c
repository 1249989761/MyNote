#include <stdio.h>

#include "testFunc.h"

int main(void)
{
    func(100);
    
    return 0;
}