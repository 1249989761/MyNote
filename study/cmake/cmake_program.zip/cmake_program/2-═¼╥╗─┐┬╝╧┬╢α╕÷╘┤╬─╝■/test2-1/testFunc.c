/*
** testFunc.c
*/

#include <stdio.h>
#include "testFunc.h"

void func(int data)
{
    printf("data is %d\n", data);
}