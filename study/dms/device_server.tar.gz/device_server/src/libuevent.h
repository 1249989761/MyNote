#ifndef _LIBUEVENT_H_
#define _LIBUEVENT_H_

#include <unistd.h>
#include <linux/input.h>
#include <pthread.h>

#ifdef  __cplusplus
extern "C" {
#endif

typedef struct u_event {
	char action[32]; /* EVENT_CONNECT_CONNECTED/DISCONNECTED */
	char devtype[32]; /* Possible name: "tfcard", "linein", "headset", "dlna", "airplay", "bt", "udisk", "usb"... */
	char devname[32]; /* EVENT_CONNECT_CONNECTED/DISCONNECTED */
	char devpath[512];
} u_event;

typedef void (*EventCallback) (u_event event, void *param);


void *uevent_monitor(EventCallback callback,void *param);





#ifdef  __cplusplus
}
#endif
#endif