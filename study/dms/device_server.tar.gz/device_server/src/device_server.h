/*****************************************************************************
 * Copyright (C) 2018-2019
 * file:    device_server.h
 * author:  liuxiaolong <383368144@qq.com>
 * created: 2019-04-25  
 * updated: 2019-04-25 
 *****************************************************************************/

#ifndef DEVICE_SERVER_H
#define DEVICE_SERVER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include "my_debug.h"


#define DMS_VERSION "1.1.9"
#define HARD_CAN    1
#define HARD_USB    2  

#define MAX_ID_LEN 64
#define TCP_PORT 8080
#define UDP_PORT 9090
#define UDP_AGENT_PORT 9091
#define UDP_LISTEN_PORT 9990

#define NFC_ID              1000
#define EMMC_BIB_STM32      1001


#define LISTENQ  1024  /* second argument to listen() */
#define MAXLINE 1024   /* max length of a line */
#define RIO_BUFSIZE 1024
#define BUFF_SIZE 4096

#define ERR_PARA        1001
#define ERR_WRITE       1002
#define ERR_READ        1003
#define ERR_NOT_FOUND   1004

#define LISTEN_MAX_BACKLOG  (128)
#define MTU                 (1500 - 42 - 200)
#define MAX_RETRY_CNT       (3)

typedef enum {
    GET = 0,
    POST,
    HEAD,
} http_method;

typedef struct {
    int rio_fd;                 /* descriptor for this buf */
    int rio_cnt;                /* unread byte in this buf */
    char *rio_bufptr;           /* next unread byte in this buf */
    char rio_buf[RIO_BUFSIZE];  /* internal buffer */
} rio_t;

typedef struct {
    int client_fd;
    char req_path[128];
    char url[128];
    char *recv_buff;
    int recv_len;
    int content_len;
    char *send_buff;
    http_method req_method;
    int error_code;
    char error_msg[128];
    
} http_request;

struct MemoryStruct {
  char *memory;
  size_t size;
};


#define safe_free(p) do{\
     if((p) != NULL)\
     {\
         free((p));\
         (p) = NULL;\
     }\
     }while(0)


#ifdef __cplusplus
}
#endif
#endif
