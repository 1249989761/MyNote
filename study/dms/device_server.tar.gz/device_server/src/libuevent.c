#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <pthread.h>
#include "libuevent.h"

#define UEVENT_MSG_LEN 4096
struct kernel_uevent {
	const char *action;
	const char *path;
	const char *subsystem;
	const char *firmware;
	int major;
	int minor;
	const char *devname;
	const char *devtype;
};
static int open_kernel_uevent_socket(void);
static void parse_event(const char *msg, struct kernel_uevent *kernel_uevent);

void *uevent_thread(void* data)
{
	EventCallback event_callback = (EventCallback) data;
	u_event event;
	int device_fd = -1;
	char msg[UEVENT_MSG_LEN+2];
	int n;
	struct kernel_uevent kernel_uevent;
	// int brun =1;

	device_fd = open_kernel_uevent_socket();
	// printf("--dxp-- uevent device_fd = %d\n", device_fd);

	while(1){
		if((n = recv(device_fd, msg, UEVENT_MSG_LEN, 0)) > 0) {
			// printf("---- uevent len = %d\n", n);
			msg[n] = '\0';
			msg[n+1] = '\0';
			parse_event(msg, &kernel_uevent);
			if(!strcmp(kernel_uevent.subsystem,"block")) {
				strcpy(event.action,kernel_uevent.action);
				strcpy(event.devtype,kernel_uevent.devtype);
				strcpy(event.devname,kernel_uevent.devname);
				strcpy(event.devpath,kernel_uevent.path);
				event_callback(event,NULL);
			}
			memset(&event,0,sizeof(u_event));
		}
		usleep(1000*10);
	}
	close(device_fd);
}


static int open_kernel_uevent_socket(void)
{
	struct sockaddr_nl addr;
	int sz = 64*1024;
	int s;

	memset(&addr, 0, sizeof(addr));
	addr.nl_family = AF_NETLINK;
	addr.nl_pid = getpid();
	addr.nl_groups = 0xffffffff;

	s = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
	if (s < 0)
		return -1;

	setsockopt(s, SOL_SOCKET, SO_RCVBUFFORCE, &sz, sizeof(sz));
	if (bind(s, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
		close(s);
		return -1;
 	}

 	return s;
}


static void parse_event(const char *msg, struct kernel_uevent *kernel_uevent)
{
	kernel_uevent->action = "";
	kernel_uevent->path = "";
	kernel_uevent->subsystem = "";
	kernel_uevent->firmware = "";
	kernel_uevent->major = -1;
	kernel_uevent->minor = -1;
	kernel_uevent->devname = "";
	kernel_uevent->devtype = "";

	// printf("========================================================\n");
	while (*msg) {
		// printf("%s\n", msg);
		if (!strncmp(msg, "ACTION=", 7)) {
			msg += 7;
			kernel_uevent->action = msg;
		} else if (!strncmp(msg, "DEVPATH=", 8)) {
			msg += 8;
			kernel_uevent->path = msg;
		} else if (!strncmp(msg, "SUBSYSTEM=", 10)) {
			msg += 10;
			kernel_uevent->subsystem = msg;
		} else if (!strncmp(msg, "FIRMWARE=", 9)) {
			msg += 9;
			kernel_uevent->firmware = msg;
		} else if (!strncmp(msg, "MAJOR=", 6)) {
			msg += 6;
			kernel_uevent->major = atoi(msg);
		} else if (!strncmp(msg, "MINOR=", 6)) {
			msg += 6;
			kernel_uevent->minor = atoi(msg);
		} else if (!strncmp(msg, "DEVNAME=", 8)) {
			msg += 8;
			kernel_uevent->devname = msg;
		} else if (!strncmp(msg, "DEVTYPE=", 8)) {
			msg += 8;
			kernel_uevent->devtype = msg;
		}

		while(*msg++);
	}

	// printf("event { %s, %s, %s, %s, %s, %s }\n",
	// kernel_uevent->action, kernel_uevent->path, kernel_uevent->subsystem,
	// kernel_uevent->firmware, kernel_uevent->devname, kernel_uevent->devtype);
}

void *uevent_monitor(EventCallback callback,void *param)
{
	pthread_t tid;
	param = param;
	if (0 != pthread_create(&tid, NULL, uevent_thread, (void *)callback)) {
        printf("pthread_create failed\n");
        return NULL;
    }
    pthread_detach(tid);
    return NULL;
}
