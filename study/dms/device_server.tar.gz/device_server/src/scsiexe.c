#include <unistd.h>

#include <scsi/scsi_ioctl.h>


#include <stdio.h>
#include <stdlib.h>
#include <string.h>



#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include "scsiexe.h"
#include "USBNet.h"
#include "base64.h"
#include "my_debug.h"
#include "device_server.h"


unsigned char sense_buffer[SENSE_LEN];
unsigned char data_buffer[BLOCK_LEN*256];
char bin_path[64] = {0};

/***************************************************************************
 * name: init_io_hdr
 * parameter:
 * function: initialize the sg_io_hdr struct fields with the most common
 * 			 value
 * **************************************************************************/
struct  sg_io_hdr * init_io_hdr() {

	struct sg_io_hdr * p_scsi_hdr = (struct sg_io_hdr *)malloc(sizeof(struct sg_io_hdr));
	memset(p_scsi_hdr, 0, sizeof(struct sg_io_hdr));
	if (p_scsi_hdr) {
		p_scsi_hdr->interface_id = 'S'; /* this is the only choice we have! */
		p_scsi_hdr->flags = SG_FLAG_LUN_INHIBIT; /* this would put the LUN to 2nd byte of cdb*/
	}

	return p_scsi_hdr;
}

void destroy_io_hdr(struct sg_io_hdr * p_hdr) {
	if (p_hdr) {
		free(p_hdr);
	}
}

void set_xfer_data(struct sg_io_hdr * p_hdr, void * data, unsigned int length) {
	if (p_hdr) {
		p_hdr->dxferp = data;
		p_hdr->dxfer_len = length;
	}
}

void set_sense_data(struct sg_io_hdr * p_hdr, unsigned char * data,
		unsigned int length) {
	if (p_hdr) {
		p_hdr->sbp = data;
		p_hdr->mx_sb_len = length;
	}
}

void show_hdr_outputs(struct sg_io_hdr * hdr) {
	printf("status:%d\n", hdr->status);
	printf("masked_status:%d\n", hdr->masked_status);
	printf("msg_status:%d\n", hdr->msg_status);
	printf("sb_len_wr:%d\n", hdr->sb_len_wr);
	printf("host_status:%d\n", hdr->host_status);
	printf("driver_status:%d\n", hdr->driver_status);
	printf("resid:%d\n", hdr->resid);
	printf("duration:%d\n", hdr->duration);
	printf("info:%d\n", hdr->info);
}

void show_sense_buffer(struct sg_io_hdr * hdr) {
	unsigned char * buffer = hdr->sbp;
	int i;
	for (i=0; i<hdr->mx_sb_len; ++i) {
		putchar(buffer[i]);
	}
}

void show_vendor(struct sg_io_hdr * hdr) {
	unsigned char * buffer = hdr->dxferp;
	int i;
	printf("vendor id:");
	for (i=8; i<16; ++i) {
		putchar(buffer[i]);
	}
	putchar('\n');
}

void show_product(struct sg_io_hdr * hdr) {
	unsigned char * buffer = hdr->dxferp;
	int i;
	printf("product id:");
	for (i=16; i<32; ++i) {
		putchar(buffer[i]);
	}
	putchar('\n');
}

void show_product_rev(struct sg_io_hdr * hdr) {
	unsigned char * buffer = hdr->dxferp;
	int i;
	printf("product ver:");
	for (i=32; i<36; ++i) {
		putchar(buffer[i]);
	}
	putchar('\n');
}


/***************************************************************************
 * name: execute_Inquiry
 * parameter:
 * 		fd:			file descripter
 * 		page_code:	cdb page code
 * 		evpd:			cdb evpd
 * 		p_hdr:		poiter to sg_io_hdr struct
 * function: make Inquiry cdb and execute it.
 * **************************************************************************/
int execute_Inquiry(int fd, int page_code, int evpd, struct sg_io_hdr * p_hdr) {
	unsigned char cdb[6];

	/* set the cdb format */
	cdb[0] = 0x12; /*This is for Inquery*/
	cdb[1] = evpd & 1;
	cdb[2] = page_code & 0xff;
	cdb[3] = 0;
	cdb[4] = 0xff;
	cdb[5] = 0; /*For control filed, just use 0*/
	
	p_hdr->dxfer_direction = SG_DXFER_FROM_DEV;
	p_hdr->cmdp = cdb;
	p_hdr->cmd_len = 6;

	int ret = ioctl(fd, SG_IO, p_hdr);
	if (ret<0) {
		printf("Sending SCSI Command failed.\n");
		close(fd);
		exit(1);
	}

	return p_hdr->status;
}

void *update_emmc_loop(void *argv)
{
	// char *path = (char *)argv;
	unsigned char cdb[8] = {0};
	unsigned char read_buff[512] = {0};
	int total_size = 0;
	int len = 0;
	int left_size = 0;
	int ret = -1;
	unsigned int i = 1;  // 0 or 1
	struct sg_io_hdr * p_hdr = init_io_hdr();
	

	// FILE *fp = fopen("/root/9-23.bin","rb");
	FILE *fp = fopen(bin_path,"rb");
	if(fp == NULL) {
		DMCLOG_E("can not open %s",bin_path);
		destroy_io_hdr(p_hdr);
		return NULL;
	}
	fseek(fp , 0 , SEEK_END);
	total_size = ftell(fp);
	fseek(fp , 0 , SEEK_SET);
	left_size = total_size;
	// DMCLOG_D("left_size = %d",left_size);
	int fd = open("/dev/sda", O_RDWR);
	if(fd < 0) {
		DMCLOG_E("can not open /dev/sda");
		fclose(fp);
		destroy_io_hdr(p_hdr);
		return NULL;
	}
	cdb[0] = SCSI_PrivateCMD;
	cdb[1] = OP_UpdateData;
	cdb[2] = UpdateBIBAllSPI;
	cdb[3] = 0;
	cdb[4] = 0;
	cdb[5] = 0;
	cdb[6] = 0;
	p_hdr->dxfer_direction = SG_DXFER_TO_DEV;
	set_sense_data(p_hdr, sense_buffer, SENSE_LEN);
	while((len = fread(read_buff,1,512,fp)) > 0) {
		cdb[3] = i & 0xff;
		cdb[4] = (i >> 8) & 0xff;
		cdb[5] = (i >> 16) & 0xff;
		cdb[6] = (i >> 24) & 0xff;
		left_size -= len;
		if(len < 512 || left_size == 0)
			cdb[7] = 1;
		set_xfer_data(p_hdr, read_buff, len);
		p_hdr->cmdp = cdb;
		p_hdr->cmd_len = 8;
		int ret = ioctl(fd, SG_IO, p_hdr);
		if (ret<0) {
			DMCLOG_E("Sending SCSI Command failed.\n");
			DMCLOG_E("index = %d",i);
			break;
		}
		printf("index = %d, len = %d\n",i,len);
		i++;

		
	}
	close(fd);
	fclose(fp);
	destroy_io_hdr(p_hdr);
	return NULL;	
}

int update_emmc_bib_bin()
{
	// struct thread *update_emmc_thread = thread_create(update_emmc_task, path);
	pthread_t tid;
	pthread_create(&tid, NULL, update_emmc_loop, NULL);
	pthread_detach(tid);
	return 0;
}

// int execute_private_cmd(int fd, int op_cmd, int sub_cmd, struct sg_io_hdr * p_hdr,int direction)
int execute_private_cmd(int fd, unsigned char *cdb, int cdb_len, struct sg_io_hdr * p_hdr,int direction)
{
	// unsigned char cdb[6];
	int ret = -1;

	// cdb[0] = SCSI_PrivateCMD;
	// cdb[1] = op_cmd;
	// cdb[2] = sub_cmd;
	// cdb[3] = 0x03;
	// cdb[4] = 0x01;
	// cdb[5] = 0x01;
	// cdb[6] = 0x0a;
	// cdb[7] = 0x00;

	// if(op_cmd == OP_UpdateData || op_cmd == OP_Update_MDT_SN)
	// 	p_hdr->dxfer_direction = SG_DXFER_TO_DEV;
	// else
	// 	p_hdr->dxfer_direction = SG_DXFER_FROM_DEV;

	/* 发送指令会卡住的问题，是数据传输方向的问题 !!!*/
	if(direction == 0)
		p_hdr->dxfer_direction = SG_DXFER_FROM_DEV;
	else if(direction == 1)
		p_hdr->dxfer_direction = SG_DXFER_TO_DEV;
	
	p_hdr->cmdp = cdb;
	if(cdb_len > 16)
		p_hdr->cmd_len = 16;
	else
		p_hdr->cmd_len = cdb_len;

	
	ret = ioctl(fd, SG_IO, p_hdr);
	if (ret<0) {
		DMCLOG_E("Sending SCSI Command failed.\n");
		close(fd);
		exit(1);
	}

	return p_hdr->status;
	
}

char *emmc_bib_cmd_execute(const char *buff,int length,int response_len)
{
	
	int cmd = 0;
	int sub_cmd = 0;
	char *enc = NULL;
	unsigned char *dec = NULL;
	// char bin_path[64] = {0};
	t_emmc_bib_cmd bib_cmd;
	int i = 0;
	int decsize = 0;
	int direction = 0;

	memset(data_buffer,0,sizeof(data_buffer));
	dec = b64_decode(buff, length, &decsize);
	memcpy(&bib_cmd,dec,sizeof(t_emmc_bib_cmd));
	DMCLOG_D("%02X %02X %02X",bib_cmd.bPrivCMD,bib_cmd.bOP,bib_cmd.bSubOP);
	DMCLOG_D("decsize= %d",decsize);
	if(bib_cmd.bOP == OP_UpdateData) {
		if(bib_cmd.bSubOP == UpdateBIBSN)
			// memcpy(data_buffer,dec+sizeof(t_emmc_bib_cmd),BIBSNLen);
			memcpy(data_buffer,dec+16,BIBSNLen);
		else if(bib_cmd.bSubOP == UpdateBIBAllSPI) {
			memset(bin_path,0,sizeof(bin_path));
			strcpy(bin_path,dec+16);
			DMCLOG_D("path = %s",bin_path);
		}
	}
	// else if(bib_cmd.bOP == OP_Update_MDT_SN) {

	// 	memcpy(data_buffer,dec+sizeof(t_emmc_bib_cmd),sizeof(ty_MDT_SN));
	// 	/* for(i=0;i<sizeof(ty_MDT_SN);i++) {
	// 		printf("%02x ",data_buffer[i]);
	// 	}
	// 	printf("\n"); */
	// }
	else if(decsize > 16)
	{
		// memcpy(data_buffer,dec+sizeof(t_emmc_bib_cmd),decsize-sizeof(t_emmc_bib_cmd));
		memcpy(data_buffer,dec+16,decsize-16);
	}

	if(response_len > 0)
		direction = 0;
	else
		direction = 1;
	
	// safe_free(dec);
	if(bib_cmd.bOP == OP_UpdateData && bib_cmd.bSubOP == UpdateBIBAllSPI) {
		// update_emmc_bib_bin();
		update_emmc_loop(NULL);
		safe_free(dec);
		return NULL;
	}
	// direction = 0;

	struct sg_io_hdr * p_hdr = init_io_hdr();
	// set_xfer_data(p_hdr, data_buffer, BLOCK_LEN*256);
	// if(bib_cmd.bOP == OP_GetUID)
	// 	set_xfer_data(p_hdr, data_buffer, 2048);
	// else if(bib_cmd.bOP == OP_CheckCur)
	// 	set_xfer_data(p_hdr, data_buffer, 1024);
	// else if(bib_cmd.bOP == OP_TestStart)
	// 	set_xfer_data(p_hdr, data_buffer, response_len);
	// else
	// 	set_xfer_data(p_hdr, data_buffer, BLOCK_LEN*256);

	if(response_len > 0) {
		set_xfer_data(p_hdr, data_buffer, response_len);
	}
	else {
		set_xfer_data(p_hdr, data_buffer, decsize-16);
	}

	set_sense_data(p_hdr, sense_buffer, SENSE_LEN);


	int status = 0;
	int fd = open("/dev/sda", O_RDWR);
	if (fd>0) {
		status = execute_private_cmd(fd, dec, decsize, p_hdr,direction);
		DMCLOG_D("the return status is %d\n", status);
		if (status!=0) {
			show_sense_buffer(p_hdr);
		} else{
			
			int read_len = 0;
			/* switch (bib_cmd.bOP)
			{
			case OP_BIBInfo:
				if(bib_cmd.bSubOP == 0)
					read_len = sizeof(tyBIBInfo);
				else if(bib_cmd.bSubOP == 1)
					read_len = 1;
				else if(bib_cmd.bSubOP == 2)
					read_len = BIBSNLen;
				break;
			case OP_BIBTestPrg:
				if(bib_cmd.bSubOP == 0)
					read_len = sizeof(tyBIBTestProgress);
				else
					read_len = 3;
				
				break;
			case OP_CheckCur:
				read_len = sizeof(tyUSBCmd_CheckCurrent);
				break;
			case OP_TestTimeout:
				read_len = 4;
				break;
			case OP_TestStart:
				read_len = 1;
				break;
			case OP_GetLogData:
				if(bib_cmd.bSubOP == 1)
					read_len = 1;
				else if(bib_cmd.bSubOP == 2)
					read_len = sizeof(tyEMMCLOGData);
				break;
			case OP_UpdateData:
			case OP_Update_MDT_SN:
				close(fd);
				destroy_io_hdr(p_hdr);
				return NULL;	
				break;
			case OP_WaitDownloadComplete:
				read_len = 1;
				break;
			case OP_GetUID:
				// read_len = sizeof(tyGetEMMCID);
				read_len = 2048;
				break;			

			default:
				break;
			} */
			DMCLOG_D("response_len = %d", response_len);
			for(i=0;i<response_len;i++) {
				printf("%02x ",data_buffer[i]);
				if((i+1)%16 == 0)
					printf("\n");
			}
			printf("\n");
			if(response_len > 0) {
				enc = b64_encode(data_buffer,response_len);
				printf("%s\n",enc);
			}
		}
	} else {
		printf("failed to open sg file\n");
	}
	safe_free(dec);
	close(fd);
	destroy_io_hdr(p_hdr);
	if(response_len > 0	)
		return enc;	
	else
	{
		return NULL;
	}
	
}
