/*****************************************************************************
 * Copyright (C) 2018-2019
 * file:    disk.c
 * author:  liuxiaolong <383368144@qq.com>
 * created: 2019-04-25 
 * updated: 2019-04-25 
 *****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <net/if.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <errno.h>
#include <assert.h>
#include <signal.h>
#define __USE_GNU 1
#include <fcntl.h>

//#include <libmacro.h>
#include "disk.h"
#include "my_debug.h"



#if (USB_DEV_COUNT == 40)
usb_port_map usb_port_map_list[41] = 
{
    { "1-1.1.1" , 0 },
    { "1-1.2.7" , 0 },
    { "1-1.2.6" , 0 },
    { "1-1.2.5" , 0 },
    { "1-1.1.2" , 0 },
    { "1-1.2.2" , 0 },
    { "1-1.2.3" , 0 },
    { "1-1.2.4" , 0 },
    { "1-1.1.3" , 0 },
    { "1-1.1.6" , 0 },
    { "1-1.1.7" , 0 },
    { "1-1.2.1" , 0 },
    { "1-1.1.4" , 0 },
    { "1-1.1.5" , 0 },
    { "1-1.6.4" , 0 },
    { "1-1.6.5" , 0 },
    { "1-1.3.1" , 0 },
    { "1-1.4.7" , 0 },
    { "1-1.6.2" , 0 },
    { "1-1.6.3" , 0 },
    { "1-1.3.2" , 0 },
    { "1-1.4.6" , 0 },
    { "1-1.5.7" , 0 },
    { "1-1.6.1" , 0 },
    { "1-1.3.3" , 0 },
    { "1-1.4.5" , 0 },
    { "1-1.5.5" , 0 },
    { "1-1.5.6" , 0 },
    { "1-1.3.4" , 0 },
    { "1-1.4.4" , 0 },
    { "1-1.5.3" , 0 },
    { "1-1.5.4" , 0 },
    { "1-1.3.5" , 0 },
    { "1-1.4.3" , 0 },
    { "1-1.5.1" , 0 },
    { "1-1.5.2" , 0 },
    { "1-1.3.6" , 0 },
    { "1-1.3.7" , 0 },
    { "1-1.4.1" , 0 },
    { "1-1.4.2" , 0 },
    { "1-1.6.7" , 0 },

};

#elif (USB_DEV_COUNT == 8)
usb_port_map usb_port_map_list[41] = 
{
    { "1-1.2.1" , 0 },
    { "1-1.2.2" , 0 },
    { "1-1.2.3" , 0 },
    { "1-1.2.4" , 0 },
    { "1-1.1.1" , 0 },
    { "1-1.1.2" , 0 },
    { "1-1.1.3" , 0 },
    { "1-1.1.4" , 0 },

};

#elif (USB_DEV_COUNT == 20 || USB_DEV_COUNT == 12)
usb_port_map usb_port_map_list[41] = 
{

    {"1-1.1.1", 0 },
    {"1-1.2.7", 0 },
    {"1-1.2.6", 0 },
    {"1-1.2.5", 0 },
    {"1-1.1.3", 0 },
    {"1-1.1.6", 0 },
    {"1-1.1.7", 0 },
    {"1-1.2.1", 0 },
    {"1-1.3.1", 0 },
    {"1-1.4.7", 0 },
    {"1-1.6.2", 0 },
    {"1-1.6.3", 0 },
    {"1-1.3.3", 0 },
    {"1-1.4.5", 0 },
    {"1-1.5.5", 0 },
    {"1-1.5.6", 0 },
    {"1-1.3.5", 0 },
    {"1-1.4.3", 0 },
    {"1-1.5.1", 0 },
    {"1-1.5.2", 0 },

    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },

    { "1-1.6.7" , 0 },
};

#endif

int can_port_map_list[80] ;
can_disk_buff_map can_disk_buff_map_list[81];

int disk_read(char *read_buf,int length, int id)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;
// #if (defined MX6Q) || (defined M3720)
    sprintf(file_path,"%s/%s1/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,DRIVE_FILE );
// #else
    // sprintf(file_path,"%s/%s/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,DRIVE_FILE );
// #endif
    fd = open(file_path,O_RDWR|O_DIRECT);
    if(fd == -1) {
        DMCLOG_E_FILE("can not open %s\n", file_path);
        return -1;
    }
    lseek(fd, 0, SEEK_SET);
    count = read(fd,read_buf,length);
    if(count != length) {
        DMCLOG_E("read count %d < %d", count,length);
    }
    // DMCLOG_D("%s",read_buf);
    close(fd);
    // usleep(5*1000);
    return count;
}

int disk_read_timeout(char *read_buff,int length, int id)
{
    unsigned char buff[2048] __attribute__((aligned(2048)));
    int count = 0;
    unsigned int max_wait_time = 200; //1S
    int len = 0;

    while(max_wait_time--)
    {
        usleep(5000);
        memset(buff, 0, sizeof(buff));
        count = disk_read(buff, 2048, id);
        if(count == -1) {
            return -1;
        }
        else if(strlen((buff)) != 0)
        {
            //printf("[%02d] len=%d, rec=%s\n", disk->id, strlen(buff), buff);

            memcpy(read_buff + len, buff, strlen(buff));

            if(read_buff[strlen(read_buff)-1] == '\r')
            {
                // read_buff[strlen(read_buff)-1] = 0;
                break;
            }
            else
            {
                len += strlen(buff);
            }
        }
    }

    if(max_wait_time == 0)
    {
        return -1;
    }

    //DMCLOG_D("rec=%s\n", read_buff);

    return 0;
}


int disk_write(char *write_buf, int length, int id)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;

    sprintf(file_path,"%s/%s1/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,DRIVE_FILE );

    // fd = open(file_path,O_RDWR | O_CREAT | O_TRUNC | O_SYNC);
    fd = open(file_path,O_RDWR|O_DIRECT);
    if(fd == -1) {
        DMCLOG_E_FILE("can not open %s\n", file_path);
        return -1;
    }
    //DMCLOG_M("%s",write_buf);
    lseek(fd, 0, SEEK_SET);
    count = write(fd,write_buf,length);
    if(count != length) {
        DMCLOG_E("write count %d < %d", count,length);
    }
    if(count<0){
        perror("write failed");
    }
    close(fd);
    // usleep(5*1000);
    return count;
}

int disk_write_read(char *write_buf, int length, int id)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;

    sprintf(file_path,"%s/%s1/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,DRIVE_FILE );

    // fd = open(file_path,O_RDWR | O_CREAT | O_TRUNC | O_SYNC);
    fd = open(file_path,O_RDWR|O_DIRECT);
    if(fd == -1) {
        DMCLOG_E_FILE("can not open %s\n", file_path);
        return -1;
    }
    // DMCLOG_D("%s",write_buf);
    lseek(fd, 0, SEEK_SET);
    count = write(fd,write_buf,length);
     if(count != length) {
        DMCLOG_E("write count %d < %d", count,length);
    }
    usleep(10*1000);

    memset(write_buf,0,length);
    lseek(fd, 0, SEEK_SET);
    count = read(fd,write_buf,length);
    if(count != length) {
        DMCLOG_E("read count %d < %d", count,length);
    }
    close(fd);
    return count;
}

int update_disk_read(char *read_buf,int length, int id, char *com_file)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;
// #if (defined MX6Q) || (defined M3720)
    sprintf(file_path,"%s/%s1/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,com_file );
// #else
    // sprintf(file_path,"%s/%s/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,DRIVE_FILE );
// #endif
    fd = open(file_path,O_RDWR|O_DIRECT);
    if(fd == -1) {
        DMCLOG_E_FILE("can not open %s\n", file_path);
        return -1;
    }
    lseek(fd, 0, SEEK_SET);
    count = read(fd,read_buf,length);
    if(count != length) {
        DMCLOG_E("read count %d < %d", count,length);
    }
    // DMCLOG_D("read: %s",read_buf);
    close(fd);
    usleep(5*1000);
    return count;
}

int update_disk_write(char *write_buf, int length, int id, char *com_file)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;

    sprintf(file_path,"%s/%s1/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,com_file );

    // fd = open(file_path,O_RDWR | O_CREAT | O_TRUNC | O_SYNC);
    fd = open(file_path,O_RDWR|O_DIRECT);
    if(fd == -1) {
        DMCLOG_E_FILE("can not open %s\n", file_path);
        return -1;
    }
    // DMCLOG_D("%s",write_buf);
    lseek(fd, 0, SEEK_SET);
    count = write(fd,write_buf,length);
     if(count != length) {
        DMCLOG_E("write count %d < %d", count,length);
    }
    close(fd);
    usleep(5*1000);
    return count;
}

int update_disk_file(char *path,int id)
{
    char com_file_path[128] = {0};
    char cmd_line[128] = {0};
    FILE *fp = NULL;
    int fd = -1;
    unsigned long file_size;
    int read_count ;
    int left_size;
    unsigned char read_buff[2048];
    fp = fopen(path,"r");
    if(fp == NULL) {
        DMCLOG_E_FILE("can not open %s\n",path);
        return -1;
    }
    fseek(fp,0L,SEEK_END);
    file_size = ftell(fp);
    DMCLOG_D("fw size: %d Kbyte.\n",file_size/1024);
    fseek(fp,0L,SEEK_SET);
    left_size = file_size;
    sprintf(com_file_path,"%s/%s1/updata.bin",MNT_PATH,usb_port_map_list[id-1].dev_name);
    // fd = open(com_file_path,O_RDWR|O_DIRECT);
    fd = open(com_file_path,O_WRONLY | O_CREAT | O_TRUNC | O_DIRECT);
    if(fd == -1) {
        DMCLOG_E_FILE("can not open %s\n", com_file_path);
        return -1;
    }
    lseek(fd, 0, SEEK_SET);
    while(left_size) {
        memset(read_buff,0,sizeof(read_buff));
        read_count = fread(read_buff,1,2048,fp);
        DMCLOG_D("read_count: %d byte.\n",read_count);
        write(fd,read_buff,read_count);
        // usleep(50*1000);
        left_size -= read_count;
    }
    fclose(fp);
    close(fd);

    // sprintf(cmd_line,"cp %s %s/%s1/updata.bin",path,MNT_PATH,usb_port_map_list[id-1].dev_name);
    // system(cmd_line);
    // system("sync;sync;sync");

    return 0;
}

// 优化，采用队列的方式来存储数据
int can_disk_read(char *read_buf,int length)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;
    char id_buff[8] = {0};
    int id = 0;
    // int i;
// #if (defined MX6Q) || (defined M3720)
    sprintf(file_path,"%s/sda/%s",MNT_PATH,DRIVE_FILE );
// #else
    // sprintf(file_path,"%s/%s/%s",MNT_PATH,usb_port_map_list[id-1].dev_name,DRIVE_FILE );
// #endif
    fd = open(file_path,O_RDWR|O_DIRECT);
    if(fd == -1) {
        DMCLOG_E("can not open %s\n", file_path);
        return -1;
    }
    lseek(fd, 0, SEEK_SET);
    count = read(fd,read_buf,length);
    if(count != length) {
        DMCLOG_E("read count %d < %d", count,length);
    }
    // DMCLOG_D("count=%d",count);
    // DMCLOG_D("recv:%s",read_buf);
    // DMCLOG_D_FILE("");("recv:%s",read_buf);
    
    close(fd);
    if(count > 0 ) {
        if(read_buf[0] == 0 && read_buf[1] == 0)
            return count;
        // DMCLOG_D_FILE("recv:%s\n",read_buf);
        memset(id_buff,0,sizeof(id_buff));
        // if(read_buf[strlen(read_buf)-1] == '\r')
        //     read_buf[strlen(read_buf)-1] = 0;
        memcpy(id_buff,read_buf,2);
        id = atoi(id_buff);
        if(read_buf[2] == 0xcf && read_buf[3] == 0x55) {
            /* DMCLOG_D_FILE("READ [%d]: ",id,read_buf);
            for (size_t i = 0; i < 32; i++)
            {
                DMCLOG_DP_FILE("%02x ",read_buf[i]);
                if((i+1)%16 == 0)
                    DMCLOG_DP_FILE("\n");
            }
            DMCLOG_DP_FILE("\n"); */
            
        }
        else
            DMCLOG_D_FILE("READ [%d]: %s\n",id,read_buf);
        // DMCLOG_D("id:%d",id);
        if(!strncmp(can_disk_buff_map_list[id].buff,"test end",8)) {
            DMCLOG_D_FILE("[%d] this is a bug error",id);
            // DMCLOG_D("[%d] this is a bug error",id);
        }
        else {
            if(read_buf[2] == 0xcf && read_buf[3] == 0x55) {
                memset(can_disk_buff_map_list[id].buff,0,sizeof(can_disk_buff_map_list[id].buff));
                memcpy(can_disk_buff_map_list[id].buff,read_buf+2,510);
                can_disk_buff_map_list[id].data_len = 510;
            }
            else {
                if(strlen(read_buf) > 0) {
                    memset(can_disk_buff_map_list[id].buff,0,sizeof(can_disk_buff_map_list[id].buff));
                    memcpy(can_disk_buff_map_list[id].buff,read_buf+2,strlen(read_buf)-2);
                    can_disk_buff_map_list[id].data_len = strlen(read_buf)-2;
                }
                // else {
                //     memset(can_disk_buff_map_list[id].buff,0,sizeof(can_disk_buff_map_list[id].buff));
                //     can_disk_buff_map_list[id].data_len = 0;
                // }
            }
            
            // can_disk_buff_map_list[id].data_ready = 1;
        }
        
    }
    // usleep(5*1000);
    return count;
}

int can_disk_write(char *write_buf, int length)
{
    int fd = -1;
    char file_path[32] = {0};
    int count = 0;
    FILE *fp = NULL;
    char id_buff[8] = {0};
    int id = 0;

    sprintf(file_path,"%s/sda/%s",MNT_PATH, DRIVE_FILE );

    // fd = open(file_path,O_RDWR | O_CREAT | O_TRUNC | O_SYNC);
    // fd = open(file_path,O_RDWR | O_SYNC);
    fd = open(file_path,O_RDWR | O_DIRECT);
    if(fd == -1) {
        DMCLOG_E("can not open %s\n", file_path);
        return -1;
    }
    memset(id_buff,0,sizeof(id_buff));
    memcpy(id_buff,write_buf,2);
    id = atoi(id_buff);
    DMCLOG_D_FILE("WRITE [%d]: %s\n",id,write_buf);

    lseek(fd, 0, SEEK_SET);
    count = write(fd,write_buf,length);
     if(count != length) {
        DMCLOG_E("write count %d < %d", count,length);
    }
    close(fd);
    // fp = fopen(file_path,)

    usleep(5*1000);
    return count;
}
