/*****************************************************************************
 * Copyright (C) 2018-2019
 * file:    device_server.c
 * author:  liuxiaolong <383368144@qq.com>
 * created: 2019-04-25 
 * updated: 2019-04-25 
 *****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <net/if.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <errno.h>
#include <assert.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <curl/curl.h>

#include "device_server.h"
#include "disk.h"
#include "my_debug.h"
#include "my_json.h"
#include "libuevent.h"
#include "mongoose.h"

#include "libgevent.h"
#include "libskt.h"
#include "libthread.h"
#include "scsiexe.h"
#include "base64.h"


static int udp_fd = -1;
static int udp_agent_fd = -1;
static int g_dev_count = 0;
static int ukey_status = 0;   // ukey status

static const char *s_http_port = "8080";
static const char *s_http_port_second = "8081";
static struct mg_serve_http_opts s_http_server_opts;

int hard_type = 0;
static int hub_status = 0;

#if (USB_DEV_COUNT == 40)
usb_port_map usb_port_map_list_record[41] = 
{
    { "1-1.1.1" , 0 },
    { "1-1.2.7" , 0 },
    { "1-1.2.6" , 0 },
    { "1-1.2.5" , 0 },
    { "1-1.1.2" , 0 },
    { "1-1.2.2" , 0 },
    { "1-1.2.3" , 0 },
    { "1-1.2.4" , 0 },
    { "1-1.1.3" , 0 },
    { "1-1.1.6" , 0 },
    { "1-1.1.7" , 0 },
    { "1-1.2.1" , 0 },
    { "1-1.1.4" , 0 },
    { "1-1.1.5" , 0 },
    { "1-1.6.4" , 0 },
    { "1-1.6.5" , 0 },
    { "1-1.3.1" , 0 },
    { "1-1.4.7" , 0 },
    { "1-1.6.2" , 0 },
    { "1-1.6.3" , 0 },
    { "1-1.3.2" , 0 },
    { "1-1.4.6" , 0 },
    { "1-1.5.7" , 0 },
    { "1-1.6.1" , 0 },
    { "1-1.3.3" , 0 },
    { "1-1.4.5" , 0 },
    { "1-1.5.5" , 0 },
    { "1-1.5.6" , 0 },
    { "1-1.3.4" , 0 },
    { "1-1.4.4" , 0 },
    { "1-1.5.3" , 0 },
    { "1-1.5.4" , 0 },
    { "1-1.3.5" , 0 },
    { "1-1.4.3" , 0 },
    { "1-1.5.1" , 0 },
    { "1-1.5.2" , 0 },
    { "1-1.3.6" , 0 },
    { "1-1.3.7" , 0 },
    { "1-1.4.1" , 0 },
    { "1-1.4.2" , 0 },
    { "1-1.6.7" , 0 },

};

#elif (USB_DEV_COUNT == 8)
usb_port_map usb_port_map_list_record[41] = 
{
    { "1-1.2.1" , 0 },
    { "1-1.2.2" , 0 },
    { "1-1.2.3" , 0 },
    { "1-1.2.4" , 0 },
    { "1-1.1.1" , 0 },
    { "1-1.1.2" , 0 },
    { "1-1.1.3" , 0 },
    { "1-1.1.4" , 0 },

};

#elif (USB_DEV_COUNT == 20 || USB_DEV_COUNT == 12)
usb_port_map usb_port_map_list_record[41] = 
{

    {"1-1.1.1", 0 },
    {"1-1.2.7", 0 },
    {"1-1.2.6", 0 },
    {"1-1.2.5", 0 },
    {"1-1.1.3", 0 },
    {"1-1.1.6", 0 },
    {"1-1.1.7", 0 },
    {"1-1.2.1", 0 },
    {"1-1.3.1", 0 },
    {"1-1.4.7", 0 },
    {"1-1.6.2", 0 },
    {"1-1.6.3", 0 },
    {"1-1.3.3", 0 },
    {"1-1.4.5", 0 },
    {"1-1.5.5", 0 },
    {"1-1.5.6", 0 },
    {"1-1.3.5", 0 },
    {"1-1.4.3", 0 },
    {"1-1.5.1", 0 },
    {"1-1.5.2", 0 },

    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },
    {"\0", 0 },

    { "1-1.6.7" , 0 },
};

#endif

// #define BUFFRE_LENGTH 8192
#define BUFFRE_LENGTH 2048
#define BUFFRE_LENGTH_4K 4096
// static char g_buff[BUFFRE_LENGTH] __attribute__((aligned(BUFFRE_LENGTH)));

int print_now_time(char *now_time)
{
    time_t timer;
    struct tm *curr_time;
    time(&timer);
    curr_time = localtime(&timer);
    // printf("[%4d-%02d-%02d %02d:%02d:%02d] ", (1900 + curr_time->tm_year),
    // (1 + curr_time->tm_mon),curr_time->tm_mday,curr_time->tm_hour,curr_time->tm_min,curr_time->tm_sec);
    sprintf(now_time,"[%4d-%02d-%02d %02d:%02d:%02d] ",(1900 + curr_time->tm_year),
    (1 + curr_time->tm_mon),curr_time->tm_mday,curr_time->tm_hour,curr_time->tm_min,curr_time->tm_sec);
    return 0;
}

int skt_udp_connect_lxl(const char *host, uint16_t port)
{
    // return _skt_connect(SOCK_DGRAM, host, port);
    int domain = AF_INET;
    int type = SOCK_DGRAM;
    int protocol = 0;
    struct sockaddr_in si;
    
    if (type < 0 || strlen(host) == 0 || port >= 0xFFFF) {
        printf("invalid paraments\n");
        return -1;
    }
    
    int fd = socket(domain, type, protocol);
    if (-1 == fd) {
        printf("socket: %s\n", strerror(errno));
        goto fail;
    }

    si.sin_family = domain;
    si.sin_addr.s_addr = inet_addr(host);
    si.sin_port = htons(port);
    if (-1 == connect(fd, (struct sockaddr*)&si, sizeof(si))) {
        printf("connect failed: %s\n", strerror(errno));
        goto fail;
    }
    
    return fd;
fail:
    if (-1 != fd) {
        close(fd);
    }
    
    return -1;
}


void event_cb(u_event event, void *param)
{
    int dev_id = 0;
    DMCLOG_M("======================================");
    DMCLOG_M("action : %s", event.action);
    DMCLOG_M("devtype : %s", event.devtype);
    DMCLOG_M("devname : %s", event.devname);
    DMCLOG_M("devpath : %s", event.devpath);

    param = param;
    // if(strcmp(event.devtype,"partition")) {
    //     return;
    // }
    char usb_path[40] = {0};
    // char *devpath = event.devpath;
    int path_len = strlen(event.devpath);
    int i = 0, j = 0;
    char udp_send_string[128] = {0};
    i = path_len-1;
    while(event.devpath[i]) {
        if(event.devpath[i] == '/') {
            j++;
            if(j==7)  // disk is 7, partion is 8
                break;
        }
        i--;
    }
    j=0;
    i++;
    while(event.devpath[i]) {
        if(event.devpath[i] != '/') {
            usb_path[j] = event.devpath[i];
            j++;
        }
        else
            break;
        i++;
    }
    usb_path[j] = '\0';
    if(strlen(usb_path) == 0)
        return;
    DMCLOG_D("usb_path:%s",usb_path);
    for(i=0;i<41;i++) {
        if(i < 40 && !strcmp(usb_path,usb_port_map_list[i].usb_path)) {
            dev_id = i+1;
            if(!strcmp(event.action,"add")) {
                memset(usb_port_map_list[i].dev_name,0,sizeof(usb_port_map_list[i].dev_name));
                strcpy(usb_port_map_list[i].dev_name,event.devname);
                g_dev_count++;
                // DMCLOG_D("id = %d, dev_name = %s, dev_count = %d",dev_id,usb_port_map_list[i].dev_name,g_dev_count);
            }
            // else(!strcmp(event.action,"remove")) {
            //     memset(usb_port_map_list[i].dev_name,0,sizeof(usb_path,usb_port_map_list[i].dev_name));
            // }
            else if(!strcmp(event.action,"remove")) {
                if(g_dev_count > 0)
                    g_dev_count--;
                memset(usb_port_map_list[i].dev_name,0,sizeof(usb_port_map_list[i].dev_name));
            }

           // DMCLOG_M_FILE("id = %d, dev_name = %s, action = %s, dev_count = %d\n",dev_id,event.devname,event.action,g_dev_count);
            DMCLOG_M("id = %d, dev_name = %s, action = %s, dev_count = %d\n",dev_id,event.devname,event.action,g_dev_count);

             if((!strcmp(event.action,"add") || !strcmp(event.action,"remove"))&&(hub_status==0)) {
                memset(udp_send_string,0,sizeof(udp_send_string));
                sprintf(udp_send_string,"{\"dev_type\":\"disk\",\"event_type\":\"%s\",\"id\":%d}",event.action,dev_id);
                skt_send(udp_fd, udp_send_string, strlen(udp_send_string));
                skt_send(udp_agent_fd, udp_send_string, strlen(udp_send_string));
                DMCLOG_M_FILE("id = %d, dev_name = %s, action = %s, dev_count = %d\n",dev_id,event.devname,event.action,g_dev_count);
                DMCLOG_M("%s",udp_send_string);
            }
            break;
        }
        else if(i == 40 && !strcmp(usb_path,usb_port_map_list[i].usb_path)) {
            if(!strcmp(event.action,"add")) {
                memset(usb_port_map_list[i].dev_name,0,sizeof(usb_port_map_list[i].dev_name));
                strcpy(usb_port_map_list[i].dev_name,event.devname);
                // DMCLOG_D("id = %d, dev_name = %s, dev_count = %d",dev_id,usb_port_map_list[i].dev_name,g_dev_count);
            }
            else {
                memset(usb_port_map_list[i].dev_name,0,sizeof(usb_port_map_list[i].dev_name));
            }
            DMCLOG_M_FILE("id = %d, dev_name = %s, action = %s\n",dev_id,event.devname,event.action);
        }
    }
    return;
}


int init_disk_map(int cnt)
{
    int i = 0;
    char disk_name[10] = {0};
    g_dev_count = cnt;
    

    for(i=0;i<cnt;i++) {
        if(i>=26) {
            memset(disk_name,0,sizeof(disk_name));
            sprintf(disk_name,"sda%c",i-26+'a');
            strcpy(usb_port_map_list[i].dev_name,disk_name);
        }
        else {
            memset(disk_name,0,sizeof(disk_name));
            sprintf(disk_name,"sd%c",i+'a');
            strcpy(usb_port_map_list[i].dev_name,disk_name);            
        }
    }
    for(i=0;i<cnt;i++) {
        DMCLOG_D("%s",usb_port_map_list[i].dev_name);
    }
    return 0;

}

#define USB_PORT_PATH "/etc/usb_port"
int usb_port_init()
{
    char  line[1024];
    char var1[32] = {0}, var2[32] = {0};
    FILE *fp = fopen(USB_PORT_PATH,"r");
    if(fp == NULL) {
        return -1;
    }
    int i = 0;
    for(i=0;i<41;i++)
        memset(usb_port_map_list[i].usb_path,0,sizeof(usb_port_map_list[i].usb_path));
    i = 0;
    while (fgets(line, sizeof(line), fp) != NULL) {
        if( line[strlen(line) - 1] == '\n' )
            line[strlen(line) - 1] = '\0';
        memset(var1,0,sizeof(var1));
        memset(var2,0,sizeof(var2));
        if (sscanf(line, "%s %s", var1, var2) == 2) {
            // memset(usb_port_map_list[g_dev_count].usb_path,0,sizeof(usb_path,usb_port_map_list[g_dev_count].usb_path));
            strcpy(usb_port_map_list[i].usb_path,var2);
            DMCLOG_D("%s\n",usb_port_map_list[i].usb_path);
            i++;
        }
    }
    return 0;
}

size_t write_data(void* ptr, size_t size, size_t nmemb, void* stream)
{
    DMCLOG_D("%s", (char*)ptr);
    // char *user_buf = (char *)stream;
    memcpy((char *)stream,(char *)ptr, size*nmemb);

    return (size*nmemb);
}

static size_t
WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
  size_t realsize = size * nmemb;
  struct MemoryStruct *mem = (struct MemoryStruct *)userp;
  
  mem->memory = realloc(mem->memory, mem->size + realsize + 1);
  if(mem->memory == NULL) {
    /* out of memory! */ 
    printf("not enough memory (realloc returned NULL)\n");
    return 0;
  }
  
  memcpy(&(mem->memory[mem->size]), contents, realsize);
  mem->size += realsize;
  mem->memory[mem->size] = 0;
  
  return realsize;
}

int curl_ukey_get_id(char *user_buf)
{
    CURL *curl;
    CURLcode res;
    char url[128] = {0};
    char a[1024];
    struct curl_slist *list = NULL;

    strcpy(url,"http://127.0.0.1:9998/query?type=all");

    curl = curl_easy_init();
    curl_easy_setopt(curl, CURLOPT_URL, url);
    /* this example doesn't verify the server's certificate, which means we
     might be downloading stuff from an impostor */
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    // list = curl_slist_append(list, "Content-Type:application/json;charset=utf-8");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);

    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_FORBID_REUSE, 1L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3L);



    
    // curl_easy_setopt(curl, CURLOPT_POST, 1L);
    // curl_easy_setopt(curl, CURLOPT_POSTFIELDS, cmd_string);
    // curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, m_sendDataArray.GetSize());
    
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)user_buf);
    // printf("%s\n", user_buf);

    // curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, NetBackDataCB);
    // curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)this);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK)
    {
      fprintf(stderr, "curl_easy_perform() failed: %s\n",
              curl_easy_strerror(res));
    }
    else
    {
        // printf("ok ok ok\n");
    }
    curl_easy_cleanup(curl);

    return res;
}

int curl_ukey_comm(int id, char *cmd_string, void *user_buf)
{
    CURL *curl;
    CURLcode res;
    char url[128] = {0};
    char a[1024];
    struct curl_slist *list = NULL;

    sprintf(url,"http://127.0.0.1:9998/communication?id=%d&ukey=0",id);

    curl = curl_easy_init();
    curl_easy_setopt(curl, CURLOPT_URL, url);
    /* this example doesn't verify the server's certificate, which means we
     might be downloading stuff from an impostor */
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    // list = curl_slist_append(list, "Content-Type:application/json;charset=utf-8");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);

    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_FORBID_REUSE, 1L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3L);



    
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, cmd_string);
    // curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, m_sendDataArray.GetSize());
    
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)user_buf);
    // printf("%s\n", user_buf);

    // curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, NetBackDataCB);
    // curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)this);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK)
    {
      fprintf(stderr, "curl_easy_perform() failed: %s\n",
              curl_easy_strerror(res));
    }
    else
    {
        // printf("ok ok ok\n");
    }
    curl_easy_cleanup(curl);

    return res;
}

static void send_http_header(struct mg_connection *nc,int content_len)
{
    mg_printf(nc,       "HTTP/1.1 200 OK\r\n"
                        "Content-Type: text/plain\r\n"
                        "Content-Length: %d\r\n\r\n",content_len);
}


static void usbhub_restart()
{
    char readBuff[1024] = {0};
    char mount_path[64] = {0};
    char cmd_line[128] = {0};
    FILE *mount_fp = NULL;
    mount_fp = fopen("/proc/mounts","rb");
    memset(readBuff,0,sizeof(readBuff));
    while(fgets(readBuff, 1024, mount_fp) != NULL) {
        if( (sscanf(readBuff,"%*s %s %*s %*s %*s %*s",mount_path)) == 1) {
            if(strstr(mount_path,"/tmp/mnt/") != NULL) {
                memset(cmd_line,0,sizeof(cmd_line));
                sprintf(cmd_line,"umount %s",mount_path);
                system(cmd_line);
            }
            memset(mount_path,0,sizeof(mount_path));
        }
        memset(readBuff,0,sizeof(readBuff));
    }
    fclose(mount_fp);

 
#if HARD_PLATFORM == MX6Q
    system("echo 137 >/sys/class/gpio/export");
    system("echo 136 >/sys/class/gpio/export");
    system("echo out >/sys/class/gpio/gpio136/direction");
    system("echo 0 >/sys/class/gpio/gpio136/value");
    sleep(5);
    system("echo out >/sys/class/gpio/gpio137/direction");
    system("echo 0 >/sys/class/gpio/gpio137/value");

    sleep(5);
    system("echo 1 >/sys/class/gpio/gpio137/value");
    sleep(5);
    system("echo 1 >/sys/class/gpio/gpio136/value");
#else
    #if TEST_MACHINE == LS427
        //DMCLOG_M_FILE("usb hub power down.\n");
        system("echo 17 >/sys/class/gpio/export");
        system("echo out >/sys/class/gpio/gpio17/direction");
        system("echo 0 >/sys/class/gpio/gpio17/value");
        sleep(3);
        //DMCLOG_M_FILE("usb hub power up.\n");
        system("echo 1 >/sys/class/gpio/gpio17/value");

    #elif TEST_MACHINE == LS701
        DMCLOG_M_FILE("usb hub power down.\n");
        system("echo 4 >/sys/class/gpio/export");
        system("echo out >/sys/class/gpio/gpio4/direction");
        system("echo 0 >/sys/class/gpio/gpio4/value");

        system("echo 10 >/sys/class/gpio/export");
        system("echo out >/sys/class/gpio/gpio10/direction");
        system("echo 0 >/sys/class/gpio/gpio10/value");
        sleep(3);
        DMCLOG_M_FILE("usb hub power up.\n");
        system("echo 1 >/sys/class/gpio/gpio10/value");
        sleep(1);
        system("echo 1 >/sys/class/gpio/gpio4/value");
    #endif
#endif
    return NULL;

}

void handle_setting_call(struct mg_connection *nc, struct http_message *hm)
{
    char udp_send_string[128] = {0};
    int error_code = 0;
    int time = 0;
    int len = 0;
    char error_msg[100] = {0};
    char type_val[20] = {0}, time_val[20] = {0};
    JObj* response_json = JSON_NEW_EMPTY_OBJECT();

    mg_get_http_var(&hm->query_string,"type",type_val,sizeof(type_val));
    mg_get_http_var(&hm->query_string,"time",time_val,sizeof(time_val));

    if(strlen(type_val) == 0) {
        mg_http_send_error(nc,400,NULL);
        return;
    }

    if(!strcmp(type_val,"usbhub")) {
        hub_status = 1;
        time=atoi(time_val);
        len = sizeof(usb_port_map_list)/sizeof(usb_port_map);
        for (int i = 0; i < len; i++)
        {
            strcpy(usb_port_map_list_record[i].dev_name,usb_port_map_list[i].dev_name);
        }
        usbhub_restart();

        for (int i = 0; i < time; i++)
        {
            if (g_dev_count==40)
            {
                break;
            }
            sleep(1);
        }

        sleep(5);

        for (int i = 0; i < len; i++)
        {
            if ((usb_port_map_list_record[i].dev_name[0]!='\0')&&(usb_port_map_list[i].dev_name[0]=='\0'))
            {
                memset(udp_send_string,0,sizeof(udp_send_string));
                g_dev_count--;
                sprintf(udp_send_string,"{\"dev_type\":\"disk\",\"event_type\":\"remove\",\"id\":%d}",i+1);
                skt_send(udp_fd, udp_send_string, strlen(udp_send_string));
                skt_send(udp_agent_fd, udp_send_string, strlen(udp_send_string));
                DMCLOG_M_FILE("id = %d, dev_name = %s, action = remove, dev_count = %d\n",i+1,usb_port_map_list_record[i].dev_name,g_dev_count);
                //DMCLOG_M("%s",udp_send_string);
                error_code=500;
                strcpy(error_msg,"fail");
            }else if((usb_port_map_list_record[i].dev_name[0]=='\0')&&(usb_port_map_list[i].dev_name[0]!='\0')){
                memset(udp_send_string,0,sizeof(udp_send_string));
                g_dev_count++;
                sprintf(udp_send_string,"{\"dev_type\":\"disk\",\"event_type\":\"add\",\"id\":%d}",i+1);
                skt_send(udp_fd, udp_send_string, strlen(udp_send_string));
                skt_send(udp_agent_fd, udp_send_string, strlen(udp_send_string));
                DMCLOG_M_FILE("id = %d, dev_name = %s, action = add, dev_count = %d\n",i+1,usb_port_map_list_record[i].dev_name,g_dev_count);
                //DMCLOG_M("%s",udp_send_string);
                error_code=500;
                strcpy(error_msg,"fail");
            }
        }

        hub_status = 0;

        JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
        if(!error_code) {
            JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
        }
        else {
            JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
        }
    }

  
    const char *response_str = JSON_TO_STRING(response_json);
    // DMCLOG_D("%s",response_str);
    send_http_header(nc,strlen(response_str));
    mg_send(nc, response_str, strlen(response_str));
    JSON_PUT_OBJECT(response_json);
}


void handle_hub_close_call(struct mg_connection *nc, struct http_message *hm)
{
    int error_code = 0;
    char error_msg[100] = {0};
    JObj* response_json = JSON_NEW_EMPTY_OBJECT();
    DMCLOG_M("---------------hubstatus close-----------------\n");
    hub_status = 1;
    JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
    if(!error_code) {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
    }
    else {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
    }
    const char *response_str = JSON_TO_STRING(response_json);
    // DMCLOG_D("%s",response_str);
    send_http_header(nc,strlen(response_str));
    mg_send(nc, response_str, strlen(response_str));
    JSON_PUT_OBJECT(response_json);
}

void handle_hub_start_call(struct mg_connection *nc, struct http_message *hm)
{
    int error_code = 0;
    char error_msg[100] = {0};
    JObj* response_json = JSON_NEW_EMPTY_OBJECT();
    DMCLOG_M("---------------hubstatus start-----------------\n");
    hub_status = 1;
    JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
    if(!error_code) {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
    }
    else {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
    }
    const char *response_str = JSON_TO_STRING(response_json);
    // DMCLOG_D("%s",response_str);
    send_http_header(nc,strlen(response_str));
    mg_send(nc, response_str, strlen(response_str));
    JSON_PUT_OBJECT(response_json);
}

void handle_version_call(struct mg_connection *nc, struct http_message *hm)
{
    FILE *fp;
    char response_string[64] = {0};
    char ver_str[32] = "\0";
    fp = fopen("/etc/board.cfg","r");
    if(fp != NULL) {
        fread(ver_str,1,32,fp);
        fclose(fp);
        if(ver_str[strlen(ver_str)-1] == '\n')
            ver_str[strlen(ver_str)-1] = 0;
    }
    memset(response_string,0,sizeof(response_string));
    sprintf(response_string,"{\"dms_version\":\"%s\"}",DMS_VERSION);
    // sprintf(response_string,"{\"dms_version\":\"%s\"}",DMS_VERSION);
    send_http_header(nc,strlen(response_string));
    mg_send(nc, response_string, strlen(response_string));
}


void handle_query_call(struct mg_connection *nc, struct http_message *hm)
{
  
    char type_val[20] = {0}, id_val[20] = {0};
    int i;
    int error_code = 0;
    char error_msg[100] = {0};
    char ukey_buf[128] = {0};
    char disk_cnt_buff[8] = {0};
    char id_buff[4] = {0};
    int disk_cnt = 0;
    int read_count = 0;
    char g_buff[BUFFRE_LENGTH_4K] __attribute__((aligned(BUFFRE_LENGTH_4K)));
    /* Get form variables */
    mg_get_http_var(&hm->query_string,"type",type_val,sizeof(type_val));
    mg_get_http_var(&hm->query_string,"id",id_val,sizeof(id_val));

    if(strlen(type_val) == 0) {
        mg_http_send_error(nc,400,NULL);
        return;
    }

    DMCLOG_D("type=%s,id=%s",type_val,id_val);

    JObj* response_json = JSON_NEW_EMPTY_OBJECT();

    if(!strcmp(type_val,"all")) {
        JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
        if(!error_code) {
            JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
        }
        else {
            JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
        }
        if(hard_type == USB_BUS) {
            if(g_dev_count > 0) {
                JObj *response_data_array = JSON_NEW_ARRAY();
                
                for(i=0;i<40;i++) {
                    if(strlen(usb_port_map_list[i].dev_name) > 0) {
                        JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                        JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(i+1,int));
                        JSON_ADD_OBJECT(disk_id_json, "disk",JSON_NEW_OBJECT(usb_port_map_list[i].dev_name,string));
                        JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                    }
                }
                
                if(ukey_status) {
                    JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                    JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(0,int));
                    JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                }
                /* else {
                    curl_ukey_get_id(ukey_buf);
                    if(strstr(ukey_buf,"id") != NULL) {
                        JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                        JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(0,int));
                        JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                        ukey_status = 1;
                    }
                } */
                JSON_ADD_OBJECT(response_json, "data", response_data_array);
            }
            else {
                
                if(ukey_status) {
                    JObj *response_data_array = JSON_NEW_ARRAY();
                    JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                    JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(0,int));
                    JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                    JSON_ADD_OBJECT(response_json, "data", response_data_array);
                }
            /*  else {
                    curl_ukey_get_id(ukey_buf);
                    DMCLOG_D("%s",ukey_buf);
                    if(strstr(ukey_buf,"id") != NULL) {
                        JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                        JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(0,int));
                        JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                        ukey_status = 1;
                    }
                } */
                // JSON_ADD_OBJECT(response_json, "data", response_data_array);
            }
        }
        else {
            memset(g_buff,0,BUFFRE_LENGTH_4K);
            strcpy(g_buff,CAN_GET_STATUS);
            can_disk_write(g_buff, CAN_RW_LEN);
            sleep(2);
            memset(g_buff,0,BUFFRE_LENGTH_4K);
            read_count = can_disk_read(g_buff,CAN_RW_LEN);
            // DMCLOG_D("recv: %s",read_buff);
            if(can_disk_buff_map_list[0].data_len) {
                JObj *response_data_array = JSON_NEW_ARRAY();
                memcpy(disk_cnt_buff,can_disk_buff_map_list[0].buff,2);
                disk_cnt = atoi(disk_cnt_buff);
                DMCLOG_D("disk_cnt: %d",disk_cnt);
                if(disk_cnt == CAN_DEV_COUNT) {
                    for(i=0;i<CAN_DEV_COUNT;i++) {
                        JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                        JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(i+1,int));
                        JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                    }
                }
                else if(disk_cnt < CAN_DEV_COUNT && disk_cnt > 0) {
                    for(i=1;i<CAN_DEV_COUNT+1;i++) {
                        sprintf(id_buff,"%c%c",'0'+i/10,'0'+i%10);
                        if(strstr(can_disk_buff_map_list[0].buff+2,id_buff)!=NULL) {
                            JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                            JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(i,int));
                            JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                        }
                    }
                }
                if(ukey_status) {
                    JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                    JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(0,int));
                    JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                }
                JSON_ADD_OBJECT(response_json, "data", response_data_array);
                can_disk_buff_map_list[0].data_len = 0;
                // memset(can_disk_buff_map_list[0].buff,0,sizeof(can_disk_buff_map_list[0].buff));
            }
            else {    
                if(ukey_status) {
                    JObj *response_data_array = JSON_NEW_ARRAY();
                    JObj *disk_id_json = JSON_NEW_EMPTY_OBJECT();
                    JSON_ADD_OBJECT(disk_id_json, "id",JSON_NEW_OBJECT(0,int));
                    JSON_ARRAY_ADD_OBJECT (response_data_array,disk_id_json);
                    JSON_ADD_OBJECT(response_json, "data", response_data_array);
                }
            }
        }
        
    }
    else {
        if(strlen(id_val) == 0) {
            JSON_PUT_OBJECT(response_json);
            mg_http_send_error(nc,400,NULL);
            return;
        }
        JObj *response_data = JSON_NEW_EMPTY_OBJECT();
        JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
        if(!error_code) {
            JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
        }
        else {
            JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
        }
        JSON_ADD_OBJECT(response_data, "id",JSON_NEW_OBJECT(atoi(id_val),int));
        // JSON_ADD_OBJECT(response_data, "info",JSON_NEW_OBJECT("disk",string));
        JSON_ADD_OBJECT(response_data, "info",JSON_NEW_OBJECT(usb_port_map_list[atoi(id_val)-1].dev_name,string));

        JSON_ADD_OBJECT(response_json, "data", response_data);

    }

    const char *response_str = JSON_TO_STRING(response_json);
    // DMCLOG_D("%s",response_str);
    send_http_header(nc,strlen(response_str));
    mg_send(nc, response_str, strlen(response_str));
    JSON_PUT_OBJECT(response_json);

}

void handle_communication_call(struct mg_connection *nc, struct http_message *hm)
{
    char id_val[20] = {0};
    int id = 0;
    char ukey_val[20] = {0};
    int ukey = 0;
    char line[MAXLINE];
    unsigned char g_buff[BUFFRE_LENGTH_4K] __attribute__((aligned(BUFFRE_LENGTH_4K)));
    char disk_read_buff[BUFFRE_LENGTH_4K] = {0};
    char *enc = NULL;
    unsigned char *dec = NULL;
    int decsize = 0;
    JObj *r_json = NULL;
    int error_code = 0;
    char error_msg[100] = {0};
    char read_buffer[BUFF_SIZE] = {0};
    int i = 0 ;
    mg_get_http_var(&hm->query_string,"id",id_val,sizeof(id_val));
    mg_get_http_var(&hm->query_string,"ukey",ukey_val,sizeof(ukey_val));

    if(strlen(id_val) == 0) {
        mg_http_send_error(nc,400,NULL);
        return;
    }
    id = atoi(id_val);
    if(id == NFC_ID)
        id = 41;
    if(strlen(ukey_val) != 0)
        ukey = 1;

    // usleep(1000*10);

    memset(read_buffer,0,sizeof(read_buffer));
    memcpy(read_buffer,hm->body.p,hm->body.len);
    DMCLOG_M("[%-2s] RECV %s",id_val,read_buffer);
    // DMCLOG_D_FILE("[%d] %s\n",id,read_buffer);

    if(hard_type == USB_BUS) {
        if( ukey == 0 && id < NFC_ID && strlen(usb_port_map_list[atoi(id_val)-1].dev_name) == 0) {
            memset(line,0,sizeof(line));

            sprintf(line,"{\"errcode\":%d,\"errmsg\":\"%s\",\"data\":{\"result\":\"not_found\"}}",
                ERR_NOT_FOUND,"not found the device");
            send_http_header(nc,strlen(line));
            mg_send(nc, line, strlen(line));
            return;
        }
    }
    
    r_json = JSON_PARSE(read_buffer);
    if(r_json == NULL) {
      
        DMCLOG_E("access NULL");
        error_code = ERR_PARA;
        strcpy(error_msg,"post data is not a json string.");
        goto EXIT;
        
    }
    if(is_error(r_json)) {
        DMCLOG_E("error:post data is not a json string");
        error_code = ERR_PARA;
        strcpy(error_msg,"post data is not a json string.");
        goto EXIT;
    }
    JObj *mode_json = NULL;
    JObj *read_json = NULL;
    JObj *write_json = NULL;
    JObj *length_json = NULL;
    JObj *data_json = NULL;
    JObj *response_len_json = NULL;
    JObj *code_json = NULL;
    JObj *type_json = NULL;
    int length = 0;
    int response_len = 0;
    int f_base64 = 0;
    char *emmc_read_buff = NULL;
    
    int read_count = 0;
    unsigned int write_count = 0;
    const char *mode_string = NULL;
    const char *code_string = NULL;
    struct MemoryStruct chunk;
    chunk.memory = malloc(1);  /* will be grown as needed by the realloc above */ 
    chunk.size = 0;    /* no data at this point */ 

    JSON_GET_OBJECT_EX(r_json, "mode", &mode_json);
    if(mode_json != NULL) {
        mode_string = JSON_GET_OBJECT_VALUE(mode_json, string);
        // memcpy(device_info.device_id,device_id_string,strlen(device_id_string));
    }
    else {
        DMCLOG_E("json param is error.");
        error_code = ERR_PARA;
        strcpy(error_msg,"json param is error.");
        goto EXIT;
    }
    if(hard_type == USB_BUS) {
        if(!strcmp(mode_string,"read")) {
            JSON_GET_OBJECT_EX(r_json, "read", &read_json);
            if(read_json != NULL) {
                JSON_GET_OBJECT_EX(read_json, "code", &code_json);
                if(code_json != NULL) {
                    code_string = JSON_GET_OBJECT_VALUE(code_json, string);
                }
                JSON_GET_OBJECT_EX(read_json, "type", &type_json);
                if(type_json != NULL) {
                    const char *type_string = JSON_GET_OBJECT_VALUE(type_json, string);
                }
                JSON_GET_OBJECT_EX(read_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                    // read_buff = (char *)malloc(length+1);
                    // memset(read_buff,0,length+1);
                    memset(g_buff, 0, BUFFRE_LENGTH_4K);
                    if(ukey) {
                        curl_ukey_comm(0 , read_buffer , (void *)&chunk);
                        read_count = strlen(chunk.memory);
                    }
                    else {
                        // read_count = disk_read(g_buff,BUFFRE_LENGTH_4K, atoi(id_val));
                        // read_count = strlen(g_buff);
                        // DMCLOG_D("read_count = %d",read_count);
                        // for(i=0;i<read_count;i++) {
                        //     printf("%02x ",g_buff[i]);
                        //     if((i+1)%16 == 0)
                        //         printf("\n");
                        // }
                        // printf("\n");
                        memset(disk_read_buff,0,sizeof(disk_read_buff));
                        if(code_string != NULL && !strcmp(code_string,"base64")) {
                            read_count = disk_read(g_buff,BUFFRE_LENGTH_4K, atoi(id_val));
                            f_base64 = 1;
                            read_count = g_buff[2];
                            read_count = read_count << 8;
                            read_count = read_count | g_buff[3];
                            for(i=0;i<read_count+4;i++) {
                                printf("%02x ",g_buff[i]);
                                if((i+1)%16 == 0)
                                    printf("\n");
                            }
                            printf("\n");
                            enc = b64_encode(g_buff,4+read_count);
                            memcpy(disk_read_buff,enc,strlen(enc));
                            read_count = strlen(disk_read_buff);
                            free(enc);
                        }
                        else
                        {
                            //read_count = disk_read_timeout(g_buff,BUFFRE_LENGTH_4K, atoi(id_val));
                            read_count = disk_read(g_buff,BUFFRE_LENGTH_4K, atoi(id_val));
                            memcpy(disk_read_buff,g_buff,strlen(g_buff));
                            read_count = strlen(disk_read_buff);
                        }
                        
                    }
                    
                    
                }

            }

        }
        else if(!strcmp(mode_string,"write")) {
            JSON_GET_OBJECT_EX(r_json, "write", &write_json);
            if(write_json != NULL) {
                JSON_GET_OBJECT_EX(write_json, "code", &code_json);
                if(code_json != NULL) {
                    code_string = JSON_GET_OBJECT_VALUE(code_json, string);
                }
                JSON_GET_OBJECT_EX(write_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                }
                JSON_GET_OBJECT_EX(write_json, "data", &data_json);
                if(data_json != NULL) {
                    const char *data_string = JSON_GET_OBJECT_VALUE(data_json, string);
                    // DMCLOG_D("data:%s",data_string);
                    memset(g_buff, 0, BUFFRE_LENGTH_4K);
                    if(ukey) {
                        curl_ukey_comm(0 , read_buffer , (void *)&chunk);
                    }
                    else {
                        if(code_string != NULL && !strcmp(code_string,"base64")) {
                            f_base64 = 1;
                            dec = b64_decode(data_string, strlen(data_string), &decsize);
                            memcpy(g_buff,dec,decsize);
                            for(i=0;i<decsize;i++) {
                                printf("%02x ",g_buff[i]);
                                if((i+1)%16 == 0)
                                    printf("\n");
                            }
                            printf("\n");
                            free(dec);
                        }
                        else
                            memcpy(g_buff, data_string, strlen(data_string));
                        write_count = disk_write(g_buff, BUFFRE_LENGTH_4K, id);
                        if(write_count != strlen(data_string)) {
                            // req->error_code = ERR_WRITE;
                            // strcpy(req->error_msg,"write error");
                        }
                    }
                }
                
            }

        }
        else if(!strcmp(mode_string,"write_read")) {
            JSON_GET_OBJECT_EX(r_json, "write", &write_json);
            if(write_json != NULL) {
                JSON_GET_OBJECT_EX(write_json, "code", &code_json);
                if(code_json != NULL) {
                    code_string = JSON_GET_OBJECT_VALUE(code_json, string);
                }
                JSON_GET_OBJECT_EX(write_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                }
                JSON_GET_OBJECT_EX(write_json, "data", &data_json);
                if(data_json != NULL) {
                    const char *data_string = JSON_GET_OBJECT_VALUE(data_json, string);
                    // DMCLOG_D("data:%s",data_string);
                    memset(g_buff, 0, BUFFRE_LENGTH_4K);
                    if(code_string != NULL && !strcmp(code_string,"base64")) {
                        f_base64 = 1;
                        dec = b64_decode(data_string, strlen(data_string), &decsize);
                        memcpy(g_buff,dec,decsize);
                        free(dec);
                    }
                    else
                        memcpy(g_buff, data_string, strlen(data_string));
                    read_count = disk_write_read(g_buff, BUFFRE_LENGTH_4K, id);
                    // read_count = strlen(g_buff);
                    memset(disk_read_buff,0,sizeof(disk_read_buff));
                    if(code_string != NULL && !strcmp(code_string,"base64")) {
                        read_count = g_buff[2];
                        read_count = read_count << 8;
                        read_count = read_count | g_buff[3];
                        for(i=0;i<read_count+4;i++) {
                            printf("%02x ",g_buff[i]);
                            if((i+1)%16 == 0)
                                printf("\n");
                        }
                        printf("\n");
                        enc = b64_encode(g_buff,read_count+4);
                        memcpy(disk_read_buff,enc,strlen(enc));
                        read_count = strlen(disk_read_buff);
                        free(enc);
                    }
                    else
                    {
                        memcpy(disk_read_buff,g_buff,read_count);
                        read_count = strlen(disk_read_buff);
                    }
                    
                }
                
            }
        }
        else if(!strcmp(mode_string,"scsi")) {
            JSON_GET_OBJECT_EX(r_json, "write", &write_json);
            if(write_json != NULL) {
                JSON_GET_OBJECT_EX(write_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                }
                JSON_GET_OBJECT_EX(write_json, "data", &data_json);
                JSON_GET_OBJECT_EX(write_json, "response_len", &response_len_json);
                if(data_json != NULL) {
                    const char *data_string = JSON_GET_OBJECT_VALUE(data_json, string);
                    // DMCLOG_D("data:%s",data_string);
                    if(response_len_json != NULL) {
                        response_len = JSON_GET_OBJECT_VALUE(response_len_json, int);
                    }
                    emmc_read_buff = emmc_bib_cmd_execute(data_string,strlen(data_string),response_len);
                }
            }
        }
    }
    else {
        if(!strcmp(mode_string,"read")) {
            JSON_GET_OBJECT_EX(r_json, "read", &read_json);
            if(read_json != NULL) {
                JSON_GET_OBJECT_EX(read_json, "code", &code_json);
                if(code_json != NULL) {
                    code_string = JSON_GET_OBJECT_VALUE(code_json, string);
                }
                JSON_GET_OBJECT_EX(read_json, "type", &type_json);
                if(type_json != NULL) {
                    const char *type_string = JSON_GET_OBJECT_VALUE(type_json, string);
                }
                JSON_GET_OBJECT_EX(read_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                    // read_buff = (char *)malloc(length+1);
                    // memset(read_buff,0,length+1);
                    memset(g_buff, 0, BUFFRE_LENGTH_4K);
                    if(ukey) {
                        curl_ukey_comm(0 , read_buffer , (void *)&chunk);
                        read_count = strlen(chunk.memory);
                    }
                    else {
                        // read_count = disk_read(g_buff,BUFFRE_LENGTH_4K, atoi(id_val));
                        can_disk_read(g_buff,CAN_RW_LEN);
                        // read_count = can_disk_buff_map_list[id].data_len;

                        // read_count = strlen(g_buff);
                        // DMCLOG_D("read_count = %d",read_count);
                        // for(i=0;i<read_count;i++) {
                        //     printf("%02x ",g_buff[i]);
                        //     if((i+1)%16 == 0)
                        //         printf("\n");
                        // }
                        // printf("\n");
                        memset(disk_read_buff,0,sizeof(disk_read_buff));
                        if(code_string != NULL && !strcmp(code_string,"base64")) {
                            f_base64 = 1;
                            /* read_count = g_buff[2];
                            read_count = read_count << 8;
                            read_count = read_count | g_buff[3];
                            for(i=0;i<read_count+4;i++) {
                                printf("%02x ",g_buff[i]);
                                if((i+1)%16 == 0)
                                    printf("\n");
                            }
                            printf("\n"); */
                            if(can_disk_buff_map_list[id].data_len == 510) {
                                enc = b64_encode(can_disk_buff_map_list[id].buff,510);
                                memcpy(disk_read_buff,enc,strlen(enc));
                                read_count = strlen(disk_read_buff);
                                free(enc);
                                can_disk_buff_map_list[id].data_len = 0;
                                memset(can_disk_buff_map_list[id].buff,0,sizeof(can_disk_buff_map_list[id].buff));
                            }
                            else {
                                read_count = 0;
                            }
                        }
                        else
                        {
                            if(strlen(can_disk_buff_map_list[id].buff)) {
                                memcpy(disk_read_buff,can_disk_buff_map_list[id].buff,strlen(can_disk_buff_map_list[id].buff));
                                read_count = strlen(disk_read_buff);
                                // if(!strncmp(disk_read_buff,"test end",8)) {
                                //     memset(can_disk_buff_map_list[id].buff,0,sizeof(can_disk_buff_map_list[id].buff));
                                //     can_disk_buff_map_list[id].data_len = 0;
                                // }
                                memset(can_disk_buff_map_list[id].buff,0,sizeof(can_disk_buff_map_list[id].buff));
                                can_disk_buff_map_list[id].data_len = 0;
                            }
                            else {
                                read_count = 0;
                            }
                        }
                        
                    }
                    
                    
                }

            }

        }
        else if(!strcmp(mode_string,"write")) {
            JSON_GET_OBJECT_EX(r_json, "write", &write_json);
            if(write_json != NULL) {
                JSON_GET_OBJECT_EX(write_json, "code", &code_json);
                if(code_json != NULL) {
                    code_string = JSON_GET_OBJECT_VALUE(code_json, string);
                }
                JSON_GET_OBJECT_EX(write_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                }
                JSON_GET_OBJECT_EX(write_json, "data", &data_json);
                if(data_json != NULL) {
                    const char *data_string = JSON_GET_OBJECT_VALUE(data_json, string);
                    DMCLOG_D("data:%s",data_string);
                    memset(g_buff, 0, BUFFRE_LENGTH_4K);
                    if(ukey) {
                        curl_ukey_comm(0 , read_buffer , (void *)&chunk);
                    }
                    else {
                        if(code_string != NULL && !strcmp(code_string,"base64")) {
                            f_base64 = 1;
                            // dec = b64_decode(data_string, strlen(data_string), &decsize);
                            // memcpy(g_buff,dec,decsize);
                            // for(i=0;i<decsize;i++) {
                            //     printf("%02x ",g_buff[i]);
                            //     if((i+1)%16 == 0)
                            //         printf("\n");
                            // }
                            // printf("\n");
                            // free(dec);
                            // write_count = disk_write(g_buff, BUFFRE_LENGTH_4K, id);
                        }
                        else {
                            // memcpy(g_buff, data_string, strlen(data_string));  
                            sprintf(g_buff,"%c%c%s",id/10+'0',id%10+'0',data_string);
                            DMCLOG_D("g_buff: %s",g_buff);
                            can_disk_write(g_buff, CAN_RW_LEN);
                        }
                        
                        if(write_count != strlen(data_string)) {
                            // req->error_code = ERR_WRITE;
                            // strcpy(req->error_msg,"write error");
                        }
                    }
                }
                
            }

        }

        else if(!strcmp(mode_string,"scsi")) {
            JSON_GET_OBJECT_EX(r_json, "write", &write_json);
            if(write_json != NULL) {
                JSON_GET_OBJECT_EX(write_json, "length", &length_json);
                if(length_json != NULL) {
                    length = JSON_GET_OBJECT_VALUE(length_json, int);
                }
                JSON_GET_OBJECT_EX(write_json, "data", &data_json);
                JSON_GET_OBJECT_EX(write_json, "response_len", &response_len_json);
                if(data_json != NULL) {
                    const char *data_string = JSON_GET_OBJECT_VALUE(data_json, string);
                    // DMCLOG_D("data:%s",data_string);
                    if(response_len_json != NULL) {
                        response_len = JSON_GET_OBJECT_VALUE(response_len_json, int);
                    }
                    emmc_read_buff = emmc_bib_cmd_execute(data_string,strlen(data_string),response_len);
                }
            }
        }
    }
    JObj* response_json = JSON_NEW_EMPTY_OBJECT();
    // JObj* result_json = JSON_NEW_EMPTY_OBJECT();
    JObj* data_json_res = JSON_NEW_EMPTY_OBJECT();
    JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
    if(!error_code) {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
    }
    else {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
    }
    // JSON_ADD_OBJECT(result_json, "result",JSON_NEW_OBJECT("ok",string));
    if(error_code == 0)
        JSON_ADD_OBJECT(data_json_res, "result",JSON_NEW_OBJECT("ok",string));
    else
        JSON_ADD_OBJECT(data_json_res, "result",JSON_NEW_OBJECT("fail",string));

   

    if(!strcmp(mode_string,"read") || !strcmp(mode_string,"write_read")) {
        JObj* read_json_res = JSON_NEW_EMPTY_OBJECT();
        
        JSON_ADD_OBJECT(read_json_res, "length",JSON_NEW_OBJECT(read_count,int));
        JSON_ADD_OBJECT(read_json_res, "data",JSON_NEW_OBJECT(disk_read_buff,string));
        if(f_base64) {
            JSON_ADD_OBJECT(read_json_res, "code",JSON_NEW_OBJECT("base64",string));
        }
        else
        {
            JSON_ADD_OBJECT(read_json_res, "code",JSON_NEW_OBJECT("string",string));
        }
        
        JSON_ADD_OBJECT(data_json_res, "read" ,read_json_res);
    }
    else if(!strcmp(mode_string,"scsi") && emmc_read_buff != NULL) {
        JObj* read_json_res = JSON_NEW_EMPTY_OBJECT();
        JSON_ADD_OBJECT(read_json_res, "length",JSON_NEW_OBJECT(strlen(emmc_read_buff),int));
        JSON_ADD_OBJECT(read_json_res, "data",JSON_NEW_OBJECT(emmc_read_buff,string));
        JSON_ADD_OBJECT(data_json_res, "read" ,read_json_res);
    }


    JSON_ADD_OBJECT(response_json, "data",data_json_res);

    const char *response_str = JSON_TO_STRING(response_json);
    // DMCLOG_D("%s",response_str);

    if(ukey == 0) {
        send_http_header(nc,strlen(response_str));
        mg_send(nc, response_str, strlen(response_str));
        // DMCLOG_D("[%d] Content-Length: %d",id,strlen(response_str));
        DMCLOG_M("[%d] RESPONSE %s",id,response_str);
        // DMCLOG_D_FILE("[%d] Content-Length: %d\n",id,strlen(response_str));
        // DMCLOG_D_FILE("[%d] %s\n",id,response_str);
        safe_free(emmc_read_buff);
    }
    else {
        send_http_header(nc,strlen(chunk.memory));
        mg_send(nc, chunk.memory, strlen(chunk.memory));
    }
    JSON_PUT_OBJECT(response_json);
    // safe_free(read_buff);
    if(chunk.memory)
        free(chunk.memory);

    if(r_json != NULL)
        JSON_PUT_OBJECT(r_json);

    return;
EXIT:
    memset(line,0,sizeof(line));

    sprintf(line,"{\"errcode\":%d,\"errmsg\":\"%s\"}",error_code,error_msg);
    // mg_send_head(nc,200,strlen(line),"Content-Type: text/plain");
    send_http_header(nc,strlen(line));
    mg_send(nc, line, strlen(line));
    if(r_json != NULL)
        JSON_PUT_OBJECT(r_json);

}

void handle_update_call(struct mg_connection *nc, struct http_message *hm)
{
    char id_val[20] = {0};
    int id = 0;
    
    char line[MAXLINE];
    unsigned char g_buff[BUFFRE_LENGTH_4K] __attribute__((aligned(BUFFRE_LENGTH_4K)));
    char disk_read_buff[BUFFRE_LENGTH_4K] = {0};
    char *enc = NULL;
    unsigned char *dec = NULL;
    int decsize = 0;
    JObj *r_json = NULL;
    int error_code = 0;
    char error_msg[100] = {0};
    char read_buffer[BUFF_SIZE] = {0};
    int i = 0 ;
    mg_get_http_var(&hm->query_string,"id",id_val,sizeof(id_val));


    if(strlen(id_val) == 0) {
        mg_http_send_error(nc,400,NULL);
        return;
    }
    id = atoi(id_val);
    if(id == NFC_ID)
        id = 41;

    // usleep(1000*10);

    memset(read_buffer,0,sizeof(read_buffer));
    memcpy(read_buffer,hm->body.p,hm->body.len);
    DMCLOG_M("[%-2s] %s",id_val,read_buffer);
    DMCLOG_D_FILE("[%d] %s\n",id,read_buffer);

    if( id < NFC_ID && strlen(usb_port_map_list[atoi(id_val)-1].dev_name) == 0) {
        memset(line,0,sizeof(line));

        sprintf(line,"{\"errcode\":%d,\"errmsg\":\"%s\",\"data\":{\"result\":\"not_found\"}}",
            ERR_NOT_FOUND,"not found the device");
        send_http_header(nc,strlen(line));
        mg_send(nc, line, strlen(line));
        return;
    }
    
    r_json = JSON_PARSE(read_buffer);
    if(r_json == NULL) {
      
        DMCLOG_E("access NULL");
        error_code = ERR_PARA;
        strcpy(error_msg,"post data is not a json string.");
        goto EXIT;
        
    }
    if(is_error(r_json)) {
        DMCLOG_E("error:post data is not a json string");
        error_code = ERR_PARA;
        strcpy(error_msg,"post data is not a json string.");
        goto EXIT;
    }

    JObj *mode_json = NULL;
    JObj *path_json = NULL;
    JObj *cmd_json = NULL;
    JObj *com_file_json = NULL;
    JObj *length_json = NULL;
    JObj *code_json = NULL;

    const char *mode_string = NULL;
    const char *path_string = NULL;
    const char *cmd_string = NULL;
    const char *com_file_string = NULL;
    const char *code_string = NULL;

    int length = 0;
    int response_len = 0;
    int read_count = 0;
    int write_count = 0;
    int f_base64 = 0;
    int ret ;

    JSON_GET_OBJECT_EX(r_json, "mode", &mode_json);
    if(mode_json != NULL) {
        mode_string = JSON_GET_OBJECT_VALUE(mode_json, string);
        // memcpy(device_info.device_id,device_id_string,strlen(device_id_string));
    }
    else {
        DMCLOG_E("json param is error.");
        error_code = ERR_PARA;
        strcpy(error_msg,"json param is error.");
        goto EXIT;
    }
    if(!strcmp(mode_string,"read")) {
        JSON_GET_OBJECT_EX(r_json, "length", &length_json);
        if(length_json != NULL) {
            length = JSON_GET_OBJECT_VALUE(length_json, int);
        }
        JSON_GET_OBJECT_EX(r_json, "com_file", &com_file_json);
        if(com_file_json != NULL) {
            com_file_string = JSON_GET_OBJECT_VALUE(com_file_json, string);
        }
        JSON_GET_OBJECT_EX(r_json, "code", &code_json);
        if(code_json != NULL) {
            code_string = JSON_GET_OBJECT_VALUE(code_json, string);
        }
        
        read_count = update_disk_read(g_buff,BUFFRE_LENGTH_4K, id, com_file_string);
        if(read_count == -1) {
            DMCLOG_E("can not open %s.",com_file_string);
            error_code = ERR_NOT_FOUND;
            strcpy(error_msg,"not found the device.");
            goto EXIT;
        }
        if(code_string != NULL && !strcmp(code_string,"base64")) {
            f_base64 = 1;
            read_count = g_buff[2];
            read_count = read_count << 8;
            read_count = read_count | g_buff[3];
            for(i=0;i<read_count+4;i++) {
                printf("%02x ",g_buff[i]);
                if((i+1)%16 == 0)
                    printf("\n");
            }
            printf("\n");
            DMCLOG_D("%s\n",g_buff+4);
            enc = b64_encode(g_buff,4+read_count);
            memcpy(disk_read_buff,enc,strlen(enc));
            read_count = strlen(disk_read_buff);
            free(enc);
        }
        else {
            memcpy(disk_read_buff,g_buff,strlen(g_buff));
            read_count = strlen(disk_read_buff);
        }


    }
    else if(!strcmp(mode_string,"write")) {
        JSON_GET_OBJECT_EX(r_json, "path", &path_json);
        if(path_json != NULL) {
            path_string = JSON_GET_OBJECT_VALUE(path_json, string);
        }
        JSON_GET_OBJECT_EX(r_json, "cmd", &cmd_json);
        if(cmd_json != NULL) {
            cmd_string = JSON_GET_OBJECT_VALUE(cmd_json, string);
        }
        JSON_GET_OBJECT_EX(r_json, "com_file", &com_file_json);
        if(com_file_json != NULL) {
            com_file_string = JSON_GET_OBJECT_VALUE(com_file_json, string);
        }
        JSON_GET_OBJECT_EX(r_json, "code", &code_json);
        if(code_json != NULL) {
            code_string = JSON_GET_OBJECT_VALUE(code_json, string);
        }

        if(code_string != NULL && !strcmp(code_string,"base64")) {
            f_base64 = 1;
            dec = b64_decode(cmd_string, strlen(cmd_string), &decsize);
            memcpy(g_buff,dec,decsize);
            for(i=0;i<decsize;i++) {
                printf("%02x ",g_buff[i]);
                if((i+1)%16 == 0)
                    printf("\n");
            }
            printf("\n");
            free(dec);
        }
        else
            memcpy(g_buff, cmd_string, strlen(cmd_string));
        write_count = update_disk_write(g_buff, BUFFRE_LENGTH_4K, id, com_file_string);
        if(write_count == -1) {
            DMCLOG_E("can not open %s.",com_file_string);
            error_code = ERR_NOT_FOUND;
            strcpy(error_msg,"not found the device.");
            goto EXIT;
        }
    }
    else if(!strcmp(mode_string,"update")) {
        JSON_GET_OBJECT_EX(r_json, "path", &path_json);
        if(path_json != NULL) {
            path_string = JSON_GET_OBJECT_VALUE(path_json, string);
        }

        ret = update_disk_file(path_string,id);
        if(ret != 0) {
            DMCLOG_E("can not open %s.",path_string);
            error_code = ERR_NOT_FOUND;
            strcpy(error_msg,"not found the device.");
            goto EXIT;
        }
    }

    JObj* response_json = JSON_NEW_EMPTY_OBJECT();
    // JObj* result_json = JSON_NEW_EMPTY_OBJECT();
    JObj* data_json_res = JSON_NEW_EMPTY_OBJECT();
    JSON_ADD_OBJECT(response_json, "errcode",JSON_NEW_OBJECT(error_code,int));
    if(!error_code) {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT("ok",string));
    }
    else {
        JSON_ADD_OBJECT(response_json, "errmsg",JSON_NEW_OBJECT(error_msg,string));
    }
    // JSON_ADD_OBJECT(result_json, "result",JSON_NEW_OBJECT("ok",string));
    if(error_code == 0)
        JSON_ADD_OBJECT(data_json_res, "result",JSON_NEW_OBJECT("ok",string));
    else
        JSON_ADD_OBJECT(data_json_res, "result",JSON_NEW_OBJECT("fail",string));

    if(!strcmp(mode_string,"read") ) {
        JObj* read_json_res = JSON_NEW_EMPTY_OBJECT();
        
        JSON_ADD_OBJECT(read_json_res, "length",JSON_NEW_OBJECT(read_count,int));
        JSON_ADD_OBJECT(read_json_res, "data",JSON_NEW_OBJECT(disk_read_buff,string));
        if(f_base64) {
            JSON_ADD_OBJECT(read_json_res, "code",JSON_NEW_OBJECT("base64",string));
        }
        else
        {
            JSON_ADD_OBJECT(read_json_res, "code",JSON_NEW_OBJECT("string",string));
        }
        JSON_ADD_OBJECT(data_json_res, "read" ,read_json_res);
    }

    JSON_ADD_OBJECT(response_json, "data",data_json_res);

    const char *response_str = JSON_TO_STRING(response_json);

    send_http_header(nc,strlen(response_str));
    mg_send(nc, response_str, strlen(response_str));
    // DMCLOG_D("[%d] Content-Length: %d",id,strlen(response_str));
    DMCLOG_D("[%d] %s",id,response_str);
    // DMCLOG_D_FILE("[%d] Content-Length: %d\n",id,strlen(response_str));
    DMCLOG_D_FILE("[%d] %s\n",id,response_str);
    JSON_PUT_OBJECT(response_json);
    if(r_json != NULL)
        JSON_PUT_OBJECT(r_json);

    return;
EXIT:
    memset(line,0,sizeof(line));

    sprintf(line,"{\"errcode\":%d,\"errmsg\":\"%s\"}",error_code,error_msg);
    // mg_send_head(nc,200,strlen(line),"Content-Type: text/plain");
    send_http_header(nc,strlen(line));
    mg_send(nc, line, strlen(line));
    if(r_json != NULL)
        JSON_PUT_OBJECT(r_json);
    return;
}

void udp_recv(int fd, void *arg)
{
    char buf[2048];
    memset(buf, 0, sizeof(buf));
    int ret = skt_recv(fd, buf, 2048);
    if (ret > 0) {
        DMCLOG_M("recv buf = %s\n", buf);
    } else if (ret == 0) {
        DMCLOG_D("delete connection fd:%d\n", fd);
    } else if (ret < 0) {
        DMCLOG_E("recv failed!\n");
    }

    JObj *r_json = NULL;
    r_json = JSON_PARSE(buf);
    if(r_json == NULL) {
        DMCLOG_E("access NULL");
        goto EXIT;
    }
    if(is_error(r_json)) {
        DMCLOG_E("error:post data is not a json string.");
        goto EXIT;
    }
    JObj *dev_type_json = NULL;
    JObj *event_type_json = NULL;
    JObj *id_json = NULL;
    const char *dev_type_string = NULL;
    const char *event_type_string = NULL;

    JSON_GET_OBJECT_EX(r_json,"dev_type",&dev_type_json);
    if(dev_type_json != NULL) {
        dev_type_string = JSON_GET_OBJECT_VALUE(dev_type_json,string);
    }
    else {
        DMCLOG_E("json param is error.");
        goto EXIT;
    }
    if(!strcmp(dev_type_string,"ukey")) {
        JSON_GET_OBJECT_EX(r_json,"event_type",&event_type_json);
        if(event_type_json != NULL) {
            event_type_string = JSON_GET_OBJECT_VALUE(event_type_json,string);
            if(!strcmp(event_type_string,"add")) {
                ukey_status = 1;
            }
            else if(!strcmp(event_type_string,"remove")) {
                ukey_status = 0;
            }
        }
        else {
            DMCLOG_E("json param is error.");
            goto EXIT;
        }
    }

    if(r_json != NULL)
        JSON_PUT_OBJECT(r_json);

    char udp_send_string[128] = {0};
    memset(udp_send_string,0,sizeof(udp_send_string));
    sprintf(udp_send_string,"{\"dev_type\":\"%s\",\"event_type\":\"%s\",\"id\":0}",dev_type_string,event_type_string);
    skt_send(udp_fd, udp_send_string, strlen(udp_send_string));
    skt_send(udp_agent_fd, udp_send_string, strlen(udp_send_string));    
    DMCLOG_M("%s",udp_send_string);

EXIT:
    if(r_json != NULL)
        JSON_PUT_OBJECT(r_json);
}

int udp_dispatch(struct gevent_base *evbase)
{
    gevent_base_loop(evbase);

    gevent_base_destroy(evbase);
    return 0;
}


static void *udp_dispatch_thread(struct thread *t, void *arg)
{
    struct gevent_base *s = (struct gevent_base *)arg;
    udp_dispatch(s);
    return NULL;
}

static void *usb_hub_dispatch_thread(struct thread *t, void *arg)
{
    /*int i = 0;
    char cmd_line[128] = {0};
    for(i=0;i<40;i++) {
        if(strlen(usb_port_map_list[i].dev_name) > 0) {
            memset(cmd_line,0,sizeof(cmd_line));
            sprintf(cmd_line,"umount %s/%s1",MNT_PATH,usb_port_map_list[i].dev_name);
            system(cmd_line);
            DMCLOG_D("cmd_line = %s",cmd_line);
        }
    }*/
    char readBuff[1024] = {0};
    char mount_path[64] = {0};
    char cmd_line[128] = {0};
    FILE *mount_fp = NULL;
    mount_fp = fopen("/proc/mounts","rb");
    memset(readBuff,0,sizeof(readBuff));
    while(fgets(readBuff, 1024, mount_fp) != NULL) {
        if( (sscanf(readBuff,"%*s %s %*s %*s %*s %*s",mount_path)) == 1) {
            if(strstr(mount_path,"/tmp/mnt/") != NULL) {
                memset(cmd_line,0,sizeof(cmd_line));
                sprintf(cmd_line,"umount %s",mount_path);
                system(cmd_line);
            }
            memset(mount_path,0,sizeof(mount_path));
        }
        memset(readBuff,0,sizeof(readBuff));
    }
    fclose(mount_fp);

#if HARD_PLATFORM == MX6Q
    system("echo 137 >/sys/class/gpio/export");
    system("echo 136 >/sys/class/gpio/export");
    system("echo out >/sys/class/gpio/gpio136/direction");
    system("echo 0 >/sys/class/gpio/gpio136/value");
    sleep(5);
    system("echo out >/sys/class/gpio/gpio137/direction");
    system("echo 0 >/sys/class/gpio/gpio137/value");

    sleep(5);
    system("echo 1 >/sys/class/gpio/gpio137/value");
    sleep(5);
    system("echo 1 >/sys/class/gpio/gpio136/value");
#else
    #if TEST_MACHINE == LS427
        DMCLOG_M_FILE("usb hub power down.\n");
        system("echo 17 >/sys/class/gpio/export");
        system("echo out >/sys/class/gpio/gpio17/direction");
        system("echo 0 >/sys/class/gpio/gpio17/value");
        sleep(3);
        DMCLOG_M_FILE("usb hub power up.\n");
        system("echo 1 >/sys/class/gpio/gpio17/value");

    #elif TEST_MACHINE == LS701
        DMCLOG_M_FILE("usb hub power down.\n");
        system("echo 4 >/sys/class/gpio/export");
        system("echo out >/sys/class/gpio/gpio4/direction");
        system("echo 0 >/sys/class/gpio/gpio4/value");

        system("echo 10 >/sys/class/gpio/export");
        system("echo out >/sys/class/gpio/gpio10/direction");
        system("echo 0 >/sys/class/gpio/gpio10/value");
        sleep(3);
        DMCLOG_M_FILE("usb hub power up.\n");
        system("echo 1 >/sys/class/gpio/gpio10/value");
        sleep(1);
        system("echo 1 >/sys/class/gpio/gpio4/value");
    #endif
#endif
    return NULL;

}

void on_error(int fd, void *arg)
{
    printf("error: %d\n", errno);
    // close(fd);
}



static void ev_handler(struct mg_connection *nc, int ev, void *ev_data) {
  struct http_message *hm = (struct http_message *) ev_data;

  switch (ev) {
    case MG_EV_HTTP_REQUEST:
      if (mg_vcmp(&hm->uri, "/query") == 0) {
        handle_query_call(nc,hm);
      } else if (mg_vcmp(&hm->uri, "/communication") == 0) {
        handle_communication_call(nc,hm);
      }
      else if (mg_vcmp(&hm->uri, "/dms_version") == 0) {
        handle_version_call(nc,hm);
      }
      else if (mg_vcmp(&hm->uri, "/update") == 0) {
        handle_update_call(nc,hm);
      }
      else {
        mg_http_send_error(nc,400,NULL);
      }
      break;
    default:
      break;
  }
}

static void ev_handler_second(struct mg_connection *nc, int ev, void *ev_data) {
  struct http_message *hm = (struct http_message *) ev_data;

  switch (ev) {
    case MG_EV_HTTP_REQUEST:
      if (mg_vcmp(&hm->uri,"/setting") == 0) {
        handle_setting_call(nc,hm);
      }else if (mg_vcmp(&hm->uri, "/close") == 0) {
        handle_hub_close_call(nc,hm);
      }else if (mg_vcmp(&hm->uri, "/start") == 0) {
        handle_hub_start_call(nc,hm);
      }else {
        mg_http_send_error(nc,400,NULL);
      }
      break;
    default:
      break;
  }
}

int get_hardware_type()
{
    FILE *read_fp;
    int chars_read;
    char buffer[2048] = {0};
    char cmd_line[256] = "\0";
    memset(cmd_line,0,sizeof(cmd_line));
    //sprintf(cmd_line,"find /database/syncagent/tool -name %s",file_name_string);
    strcpy(cmd_line,"lsusb | grep \"1a40\:0201\"");
    memset( buffer, 0, sizeof(buffer) ); 
    read_fp = popen(cmd_line, "r");
    chars_read = fread(buffer, sizeof(char), sizeof(buffer) , read_fp);
    pclose(read_fp);
    if(chars_read == 0) {
        hard_type = CAN_BUS;
    }
    else {
        hard_type = USB_BUS;
    }
    
    return 0;
}


int main(int argc, char **argv)
{
    struct mg_mgr mgr;
    struct mg_connection *nc;
    struct mg_connection *nc2;
    struct mg_bind_opts bind_opts;
    int i;
    char *cp;
    const char *err_str;
#if MG_ENABLE_SSL
      const char *ssl_cert = NULL;
#endif
    mg_mgr_init(&mgr, NULL);

    argc = argc;
    argv = argv;

    // init_disk_map(40);
    // usb_port_init();
    get_hardware_type();
    DMCLOG_M_FILE("------------------------- device_server start -------------------------\n");
    PRINT_M_FILE("-------------------- sys_info --------------------\n");
    // PRINT_M_FILE("USB_BUS: %d\n",USB_BUS);
    // PRINT_M_FILE("CAN_BUS: %d\n",CAN_BUS);
    PRINT_M_FILE("HARD_PLATFORM: %d (1:M3720, 2:MX6Q)\n",HARD_PLATFORM);
    PRINT_M_FILE("TEST_MACHINE: %d (1:LS427, 2:LS701, 3:LS726)\n",TEST_MACHINE);
    PRINT_M_FILE("USB_DEV_COUNT: %d\n",USB_DEV_COUNT);
    PRINT_M_FILE("HARD_TYPE: %s\n",hard_type == USB_BUS? "usb bus" : "can bus");
    PRINT_M_FILE("DMS_VERSION: %s\n",DMS_VERSION);
    PRINT_M_FILE("\n");

    udp_fd = skt_udp_connect_lxl("127.0.0.1", UDP_PORT);
    udp_agent_fd = skt_udp_connect_lxl("127.0.0.1", UDP_AGENT_PORT);
    if(hard_type == USB_BUS) {
        uevent_monitor(event_cb,NULL);
    }

    int udp_listen_fd;
    udp_listen_fd = skt_udp_bind(NULL, UDP_LISTEN_PORT);
    if (udp_listen_fd == -1) {
        return -1;
    }
    skt_set_noblk(udp_listen_fd, true);
    struct gevent_base *evbase = gevent_base_create();
    if(!evbase) 
        return -1;
    struct gevent *e = gevent_create(udp_listen_fd, udp_recv, NULL, on_error, NULL);
    if (-1 == gevent_add(evbase, e)) {
        printf("event_add failed!\n");
    }
    struct thread *dispatch_thread = thread_create(udp_dispatch_thread, evbase);
    if(hard_type == USB_BUS) {
        struct thread *usb_hub_power_ctl_thread = thread_create(usb_hub_dispatch_thread, NULL);
    }


#if (CAN_BUS == 1)

#endif

      /* Set HTTP server options */
    memset(&bind_opts, 0, sizeof(bind_opts));
    bind_opts.error_string = &err_str;
#if MG_ENABLE_SSL
    if (ssl_cert != NULL) {
        bind_opts.ssl_cert = ssl_cert;
    }
#endif

    nc = mg_bind_opt(&mgr, s_http_port, ev_handler, bind_opts);
    if (nc == NULL) {
        fprintf(stderr, "Error starting server on port %s: %s\n", s_http_port,
            *bind_opts.error_string);
        exit(1);
    }

    mg_set_protocol_http_websocket(nc);

    nc2 = mg_bind_opt(&mgr, s_http_port_second, ev_handler_second, bind_opts);
    if (nc2 == NULL) {
        fprintf(stderr, "Error starting server on port %s: %s\n", s_http_port_second,
            *bind_opts.error_string);
        exit(1);
    }
    mg_set_protocol_http_websocket(nc2);

    s_http_server_opts.enable_directory_listing = "yes";

    printf("Starting server on port %s...\n", s_http_port);
    printf("Starting server on port %s...\n", s_http_port_second);
    for (;;) {
        mg_mgr_poll(&mgr, 1000);
    }
    mg_mgr_free(&mgr);
    
    return 0;
}
