/*****************************************************************************
 * Copyright (C) 2018-2019
 * file:    cmd_chat_server.h
 * author:  liuxiaolong <383368144@163.com>
 * created: 2018-11-20 
 * updated: 2018-11-20
 *****************************************************************************/

#ifndef MY_DEBUG_H
#define MY_DEBUG_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

#define LEVEL_DEBUG     4
#define LEVEL_INFO      3
#define LEVEL_MESSAGE   2
#define LEVEL_ERROR     1
#define LEVEL_NONE      0

#define DEBUG_LEVEL LEVEL_MESSAGE
extern int print_now_time(char *now_time);

#define APPLICATION_NAME    "device_server"
#define FILE_ROOT_DIR   "/database"

#define time_now(str_time) {\
    time_t timer;\
    struct tm *curr_time;\
    time(&timer);\
    curr_time = localtime(&timer);\
    sprintf(str_time,"[%4d-%02d-%02d %02d:%02d:%02d] ",(1900 + curr_time->tm_year),\
    (1 + curr_time->tm_mon),curr_time->tm_mday,curr_time->tm_hour,curr_time->tm_min,curr_time->tm_sec);\
}

#define PRINT_M_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        print_now_time(now_time_string);\
        sprintf(fileName, "/tmp/sys_info");\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,"%s",now_time_string);\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)

#if DEBUG_LEVEL == LEVEL_DEBUG

#define DMCLOG_M(log_fmt, log_arg...) \
   do{ \
      char time_str[40];\
      time_now(time_str);\
      printf( "[MESSAGE]%s[%s:%d][%s] " log_fmt "\n", time_str,__FILE__ , __LINE__ , __FUNCTION__ , ##log_arg); \
   } while (0)
#define DMCLOG_D(log_fmt, log_arg...) \
   do{ \
      char time_str[40];\
      time_now(time_str);\
      printf( "[DEBUG]%s[%s:%d][%s] " log_fmt "\n",  time_str,__FILE__ , __LINE__ , __FUNCTION__ , ##log_arg); \
   } while (0)
#define DMCLOG_I(log_fmt, log_arg...) \
   do{ \
      char time_str[40];\
      time_now(time_str);\
      printf( "[INFO]%s[%s:%d][%s] " log_fmt "\n",  time_str,__FILE__ , __LINE__ , __FUNCTION__ , ##log_arg); \
   } while (0) 
#define DMCLOG_E(log_fmt, log_arg...) \
   do{ \
      char time_str[40];\
      time_now(time_str);\
      printf( "[ERROR]%s[%s:%d][%s] " log_fmt "\n", time_str,__FILE__ , __LINE__ , __FUNCTION__ , ##log_arg); \
   } while (0)

#define DMCLOG_D_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        print_now_time(now_time_string);\
        sprintf(fileName, "%s/%s.log", FILE_ROOT_DIR, APPLICATION_NAME);\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,"%s",now_time_string);\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)
#define DMCLOG_DP_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        sprintf(fileName, "%s/%s.log", FILE_ROOT_DIR, APPLICATION_NAME);\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)
#define DMCLOG_M_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        print_now_time(now_time_string);\
        sprintf(fileName, "%s/%s.log", FILE_ROOT_DIR, APPLICATION_NAME);\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,"%s",now_time_string);\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)
#define DMCLOG_E_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        print_now_time(now_time_string);\
        sprintf(fileName, "%s/%s.log", FILE_ROOT_DIR, APPLICATION_NAME);\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,"%s",now_time_string);\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)

#elif DEBUG_LEVEL == LEVEL_MESSAGE

#define DMCLOG_M(log_fmt, log_arg...) \
   do{ \
      char time_str[40];\
      time_now(time_str);\
      printf( "[MESSAGE]%s[%s:%d][%s] " log_fmt "\n", time_str,__FILE__ , __LINE__ , __FUNCTION__ , ##log_arg); \
   } while (0)
#define DMCLOG_D(log_fmt, log_arg...) \
   do{ \
   } while (0)
#define DMCLOG_I(log_fmt, log_arg...) \
   do{ \
   } while (0) 
#define DMCLOG_E(log_fmt, log_arg...) \
   do{ \
     printf( "[ERROR][%s:%d][%s] " log_fmt "\n", __FILE__ , __LINE__ , __FUNCTION__ , ##log_arg); \
   } while (0)

#define DMCLOG_D_FILE(log_arg...) \
   do{ \
   } while (0)
#define DMCLOG_M_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        print_now_time(now_time_string);\
        sprintf(fileName, "%s/%s.log", FILE_ROOT_DIR, APPLICATION_NAME);\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,"%s",now_time_string);\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)
#define DMCLOG_E_FILE(log_arg...) \
   do{ \
        char fileName[64] = {0},now_time_string[40] = {0};\
        print_now_time(now_time_string);\
        sprintf(fileName, "%s/%s.log", FILE_ROOT_DIR, APPLICATION_NAME);\
       FILE *fp = fopen(fileName,"a");\
       if(fp){\
                fprintf(fp,"%s",now_time_string);\
                fprintf(fp,##log_arg);\
                fclose(fp);\
       }\
    } while (0)
#else

#define DMCLOG_M(log_arg...) \
    do{ \
    } while (0)
#define DMCLOG_D(log_arg...) \
    do{ \
    } while (0)
#define DMCLOG_I(log_arg...) \
    do{ \
    } while (0)
#define DMCLOG_E(log_arg...) \
    do{ \
    } while (0)
#define DMCLOG_S(log_fmt, log_arg...) \
    do{ \
    } while (0)

#define DMCLOG_D_FILE(log_arg...) \
   do{ \
   } while (0)
#define DMCLOG_M_FILE(log_arg...) \
   do{ \
   } while (0)
#define DMCLOG_E_FILE(log_arg...) \
   do{ \
   } while (0)
#endif

#ifdef __cplusplus
}
#endif
#endif
