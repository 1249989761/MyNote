﻿/**
*******************************************************************************
*本文档定义了通讯控制板与Host之间进行通讯数据传输时的命令封装
*遵循Bulk-Only协议传输（CBW、CSW、数据）
*
*
*BYTE offset     0      1    2         6         10
*                ___________________________________________ 
*           CBW | CMD | OP  |                    Reserved   |
*               +___________________________________________+    
* CMD: 一级指令 暂定F0（使用与SCSI不冲突的SCSI指令） 
* OP:  命令码
 
*V1.0，2019.6.25，jiang.guo： 添加修改部分
*V1.1，2019.7.10，jiang.guo： 添加修改部分
*V1.2，2019.7.11，jiang.guo： 修改 


*V1.3, 2019.08.20, jiang.guo:  “tyUSBCmd_UpdateBIBData”结构体内添加：bLastData代表是否为最后一包数据。
*V1.4, 2019.08.27, jiang.guo:  添加“获取测试超时时间”指令：获取测试超时时间，若在一定时间内没完成测试，服务器会报异常。
*V1.5, 2019.09.16, jiang.guo:  添加“开始测试”指令：通知测试单元开始测试。
*V1.6, 2019.09.17, jiang.guo:  修改 测试单元的测试状态定义
*V1.7, 2019.09.30, jiang.guo:  修改 返回的Port的进度信息（添加两个位）  
*V1.8, 2019.10.08, jiang.guo:  添加 数据上传接口（预留传输log接口）  
*V1.9, 2019.11.01，jiang.guo:  添加 时间戳和序列号下发指令（OP_Update_MDT_SN）
*V2.0, 2019.11.07，jiang.guo:  添加 获取测试单元软件更新完成 指令（OP_WaitDownloadComplete）
*V2.1, 2019.11.29，jiang.guo:  (1)修改 OP_GetData 获取log数据 指令 （添加数据结构体） (2)修改 tyBIBTestProgress 内数据（添加 wMPErrorCode）
*V2.2, 2019.12.03，jiang.guo:  (1)修改 OP_GetData 获取log数据  
*V2.2, 2019.12.11，jiang.guo:  (1)添加UID获取指令：OP_GetUID  
*******************************************************************************
*@copy
*    
* <h2><center>&copy; COPYRIGHT 2019 intsys</center></h2>
*******************************************************************************
*/  

#ifndef USBNet_h
#define USBNet_h


#define TestPortTotal						    80  //总的port口数 

//CMD一级指令：
#define SCSI_PrivateCMD							0xF0  //SCSI私有命令码，所有私有命令以它开头 
 
//OP - 通讯控制板与Host之间所有的通讯命令码定义 
#define OP_BIBInfo								0x80
#define OP_BIBTestPrg							0x81
#define OP_CheckCur								0x82  
#define OP_TestTimeout						    0x83  
#define OP_TestStart						    0x84  
#define OP_GetLogData						    0x85 
#define OP_WaitDownloadComplete				    0x86 
#define OP_GetUID							    0x87 

#define OP_UpdateData							0x01 
#define OP_Update_MDT_SN						0x02 

/******************************************************************************
通讯控制板上传当前插槽上BIB的状态及信息数据 控制码：OP_BIBInfo， DATA ：Host <- Device
******************************************************************************/
#define BIBSNLen									32
//-------------------------------------------------------------------------------
//读取BIB信息通讯命令CBWCB:
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_BIBInfo
	unsigned int   dwInfoIndex;       					//指明需要返回的哪些信息
}tyUSBCmd_GetBIBInfo;
//dwInfoIndex,BIB板上很多信息可以打包一次传输，也可以单独取某个指定信息
#define BIBInfoIndex_BIB_all							0 //上传BIB所有有定义的信息
#define BIBInfoIndex_BIB_Inserted						1 //是否有BIB插入，返回一个Byte信息数据：0:没有BIB板插入   1：有BIB板插入
#define BIBInfoIndex_BIB_SN								2 //读取BIB的序列号，返回 BIBSNLen 个Byte序列号信息数据
//-------------------------------------------------------------------------------

//BIBInfoIndex_BIB_all,上传BIB所有有定义的信息,返回信息数据如下：
typedef struct  { 
	 
	unsigned char   bBIBState;							//是否有BIB板插入：0：没有BIB，BIB已被拨出  1:有BIB，BIB已插入
    unsigned char   bBIBSN[BIBSNLen];     				//BIB唯一序列号编码

	unsigned char	bCommCtrlUnitBootVer[4];			//通讯控制单元Bootload软件版本
	unsigned int   wCommCtrlUnitBootBinCheck;      	//通讯控制单元Bootload bin数据校验值
	unsigned char	bCommCtrlUnitVer[4];				//通讯控制单元控制软件版本
	unsigned int   wCommCtrlUnitBinCheck;       		//通讯控制控制软件数据校验值
	struct  {
		unsigned char	bTestCtrlUnitBootVer[4];		//测试控制单元Bootload软件版本
		unsigned int   wTestCtrlUnitBootBinCheck;		//测试控制单元Bootload bin数据校验值
		unsigned char	bTestCtrlUnitVer[4];			//测试控制单元控制软件版本
		unsigned int   wTestCtrlUnitBinCheck;      	//测试控制单元控制软件数据校验值
		
		unsigned char	bDeviceScanBinVer[4];			//被测器件自扫描软件版本
		unsigned int   wDeviceScanBinCheck;       		//被测器件自扫描软件数据校验值
		unsigned char	bDeviceLogicBinVer[4];			//被测器件逻辑控制软件版本
		unsigned int   wDeviceLogicBinCheck;      		//被测器件逻辑控制软件数据校验值
	}tTestPortInfo[TestPortTotal];	
	unsigned char	bRecordCtrlUnitBootVer[4];			//测试记录单元Bootload软件版本
	unsigned int   wRecordCtrlUnitBootBinCheck;    	//测试记录单元Bootload bin数据校验值
	unsigned char	bRecordCtrlUnitVer[4];				//测试记录单元控制软件版本
	unsigned int   wRecordCtrlUnitBinCheck;       		//测试记录控制单元控制软件数据校验值
														//DATA[4256]Byte
}tyBIBInfo;
//--------------------------------------------------------------------------------------------------

//BIBInfoIndex_BIB_Inserted,当前插槽是否有BIB插入,返回一个Byte信息数据：0:没有BIB板插入   1：有BIB板插入
#define BIB_Inserted_None			0
//--------------------------------------------------------------------------------------------------


/******************************************************************************
*BIB测试单元的进度信息，通过通讯控制板上报到PC  控制码：OP_BIBTestPrg，  DATA ：Host <- Device
******************************************************************************/
 //读取进度信息通讯命令CBWCB:
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_BIBTestPrg
	unsigned int	dwPortIndex;						//指定需要读取的测试口
}tyUSBCmd_GetTestProcess;
//dwPortIndex:指定需要读取的测试口,定义如下：
#define	TestProcessIndex_all			0				//返回所有Port的进度信息
//其它指定值：1~80， 返回指定某一测试端口的进度信息

//TestProcessIndex_all，返回所有Port的进度信息
typedef struct  {  
	struct  {
		unsigned char	bTestProject;					//测试流程：burnin、function（按需定义）BI为1 开卡 2 QC 3
		unsigned char 	bTestProgress;					//测试流程的进度（x%）
		unsigned char 	bTestStatus;					//测试状态 ：如下定义
		unsigned char  bBinInfo;						//分bin信息		
		unsigned char  bSLC_TLC;						//跑的流程是TLC或SLC		？
		unsigned char  wMPErrorCode[2];					//开卡流程的错误码
		
	}tTestPortProg[TestPortTotal];						//DATA[]Byte
 
}tyBIBTestProgress;
//TestProject:测试项，目前只测Burnin，（预留）
#define Project_Burnin			0x01
#define Project_MP				0x02
//TestStatus: 测试单元的测试状态
#define Not_Start							0xF0    //未启动
#define Running								0xF1    //运行中
#define Test_Finish							0xF2    //测试完成
#define Boot_PowerOn						0xF3    //bootloader阶段上电
#define Boot_Ready							0xF4    //更新代码完毕,可以跳到APP
#define ScanCode_Verify_Fail				0xF5    //ScanCode校验CRC失败
#define Load_ScanCode_Fail					0xF6	//详情可查看具体错误信息，bErrorMessage[0]eMMC命令码，bErrorMessage[1]eMMC命令错误详情
#define Run_ScanCode_Fail					0xF7    //Host下发待升级文件
#define EMMC_Private_Error					0xF8    //具体的错误码存于CID中
#define _8BIT_Fail							0xF9    //8bit检测失败
#define MP_Fail								0xFA    //开卡失败
 
#define StartupParamSTM32CBVersion_Error	0xE0    //启动参数CB版本号错
#define StartupParamSTM32TUVersion_Error	0xE1    //启动参数TU版本号错
#define StartupParamSTM32RUVersion_Error	0xE2    //启动参数RU版本号错
#define STM32Version_Mismatch_SPI			0xE3    //STM32运行的TU版本号与SPI的里不一致

#define Not_Insert_TestUnit					0x00	//未插BIB测试单元
#define Cmd61_Error							0x01    //CMD61失败
#define Cmd0_Error							0x02    //CMD0失败
#define Cmd1_Error							0x03    //CMD1失败
#define Cmd2_Error							0x04    //CMD2失败
#define Cmd3_Error							0x05    //CMD3失败
#define Cmd9_Error							0x06    //CMD9失败
#define Cmd7_Error							0x07    //CMD7失败
#define RB_All_LOW_Error					0x08    //RB拉不起
#define RETYR_SELECT_CARD_Error				0x09    //多次选卡失败
#define RETYR_CMD12_Error					0x0A    //多次CMD12失败
#define Cmd6_Error							0x0B    //多次CMD6失败
#define Run_In_ROM_Code						0x0C    //无法跳转到ROM CODE
#define CMD12_Error							0x0D    //cmd12命令失败
#define SPI_ScanCode_Verify_Error			0x0e    //SPI中的scan code 校验失败
#define SPI_StartParameter_Verify_Error		0x0f    //SPI中的scan code 校验失败
#define CMD16_Error							0x10    //cmd16命令失败
#define CMD25_Error							0x11    //cmd25命令失败
#define Write_Emmc_Data_Timeout				0x12    //cmd25写数据超时
#define Write_Emmc_Data_Crc					0x13    //cmd25写数据CRC
#define Write_Emmc_Data_Bit_Error			0x14    //cmd25写数据起始位出错
#define Write_Emmc_Data_Fifo_Error			0x15    //cmd25写数据起始位出错
#define CMD10_Error							0x16    //获取CID命令失败 
#define Cid_Compare_Error					0x17    //CID比较出错  
#define Write_Process_Retry_Max				0x18    //   
#define EMMC_CARD_Error_					0x19    //   EMMC_ 卡出错


#define CID_ERR_MSG_NO_TARGET_						0xA1  //找不到Flash
#define CID_ERR_MSG_STARTUP_PARAM_ID_ERROR_			0xA2  //启动参数的Flash ID和代码支持的ID不匹配
#define CID_ERR_MSG_FLASH_ID_ERROR_                 0xA3  //物理Flash ID错误
#define CID_ERR_MSG_VCMD_CRC_						0xA4  //私有命令CRC错误
#define CID_ERR_MSG_VCMD_NODATA_					0xA5  //私有命令没发送数据
#define CID_ERR_MSG_VOLT_NOT_GOOD_					0xA6  //电压值不正常
#define CID_ERR_MSG_BBT_BLOCK_IS_FULL_				0xA7  //BBT BLOCK写满
#define CID_ERR_MSG_STARTUP_PARAM_CHECKSUM_FAIL_	0xA8  //启动参数异或值不正确
#define CID_ERR_MSG_STARTUP_PARAM_DIFFER_			0xA9  //启动参数和掉电前保存不一致
#define CID_ERR_MSG_STARTUP_PARAM_INVALID_			0xAA //启动参数有数据项取值区间不对

 

//校准命令（发送指令进入校准模式，返回数据：8*80）CBWCB:
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_CheckCur
}tyUSBCmd_CheckCur;
//返回数据：
typedef struct  { 
	struct  { 
		 unsigned short  wVCC_Current_uA;	
		 unsigned short  wVCCQ_Current_uA;	
		 unsigned short  wVCC_Current_mA;	
		 unsigned short  wVCCQ_Current_mA;	
	}tTestPortCurrent[TestPortTotal];						//DATA[8*80]Byte
}tyUSBCmd_CheckCurrent;  

/******************************************************************************
*Host将各控制器及生产数据输出到通讯控制板,数据将拆分成小包传输  控制码：OP_UpdateData，  DATA ：Host -> Device
******************************************************************************/
#define UpdateDataPktSize								512
 //更新BIB数据通讯命令CBWCB:
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_UpdateData
	unsigned char	bSite;								//指明当前数据更新的位置
	unsigned int	dwPktIndex;							//当前传输的数据大于UpdateDataPktSize，需要拆包，指明当前是第几个数据包
	unsigned char	bLastData;							//是否为最后一包数据（1 TRUE  0 FALSE）
}tyUSBCmd_UpdateBIBData;  
//bSite,指明当前数据更新的位置
#define UpdateBIBAllSPI						0			//统一更新BIB上所有控制单元的数据
#define UpdateBIBSN							1			//只更新BIB的SN



/******************************************************************************
*开始测试时获取测试超时时间：在指定时间内需全部完成测试  控制码：OP_GetTestTimeOut，  DATA ：Host <- Device
******************************************************************************/
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_GetTestTimeOut
}tyUSBCmd_GetTestTimeOut;

// 发送获取测试超时时间后 返回一个DWORD数据（分为单位）： 
//unsigned int TestTimeOut;
//--------------------------------------------------------------------------------------------------

 


/******************************************************************************
*开始测试 ：   控制码：OP_TestStart，  DATA ：Host <- Device
******************************************************************************/
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_CheckCur
}tyUSBCmd_OP_TestStart;

//返回一个Byte数据状态：0 忙     1 进入测试
//unsigned char  TestStartStatus;
#define Status_Busy						0			//忙
#define Status_OK						1			//进入测试

/*
函數定义：
*/

/******************************************************************************
*上传数据 （预留）：  控制码： OP_GetLogData   DATA ：Host <- Device 
******************************************************************************/
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_GetLogData
	unsigned char	bInquiryGetLog;						//查询是否有log 1 或 获取log  2 
}tyUSBCmd_OP_GetLogData;

// bInquiryGetLog  
#define InquiryLog		1			//返回1Byte结果   
#define GetLog			2			//返回tyEMMCLOGData 数据
//InquiryLog 返回
unsigned char Result[2]; //第1字节为 0 无log  1 有log;  第2字节为 1 BI的log  2 MP的log 

//GetLog 返回
typedef struct  { 
	unsigned char		bDataValidity;					//数据有效性：  0 数据无效  1有效
	struct  {  
						unsigned char		bPort;							//port 
						unsigned char		bData_Type;						//数据类型
						unsigned short 		wBlockNum;						//Block 的地址
						unsigned char		bLog[40];						//40 Byte
		}teMMC_log[80];		//写的log内容 
}tyEMMCLOGData;
   
// bDataValidity
#define InvalidData		0  //无效数据
#define ValidData		1  //有效数据
#define BI_LatsData		2  //BI 的最后一包有效数据
#define MP_LatsData		3  //MP 的最后一包有效数据



 /******************************************************************************
*Host将EMMC生产序列号与MDT发送到通讯控制板  控制码：OP_Update_MDT_SN，  DATA ：Host -> Device 
（服务器产生一个SN码下发到机台的通讯板上，机台通讯板将以这个SN码解析成80个，下发到每个测试单元，
  之后服务器SN码自加80，再下发一个到另一个通讯板）
2019.11.1，
******************************************************************************/ 
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_Update_MDT_SN
	unsigned int	dwDatalenth;						//数据长度 
}tyUSBCmd_Update_MDT_SN;  
 
//下发的数据定义：MDT + eMMC SN  （8Byte+4Byte）
typedef struct  { 
	unsigned char	MDT[8];							//MDT时间戳64位
	unsigned char	eMMC_SN[4];						//eMMC SN 序列号32位
}ty_MDT_SN;  
 
   /******************************************************************************
*获取测试单元软件更新完成  控制码：OP_WaitDownloadComplete，  DATA ：Host <- Device 

2019.11.7，
******************************************************************************/ 
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_WaitDownloadComplete 
}tyUSBCmd_WaitDownloadComplete;  
 //返回一个Byte数据状态：0 忙     1 更新完成
//unsigned char  Uptate Status;
// int8_t SCSI_PrivateCMD_Handle(uint8_t lun, uint8_t *params);


 /******************************************************************************
*获取UID  控制码：OP_GetUID，  DATA ：Host <- Device 
备注：UID在有log数据的时候可以去获取。
2019.12.11，
******************************************************************************/ 
typedef struct  { 
	unsigned char	bPrivCMD;							//SCSI_PrivateCMD
	unsigned char	bOP;								//控制命令码:OP_GetUID 
}tyGetEMMCUID;  

 //返回数据
typedef struct  { 
	struct  {   
		unsigned char	eFUSEID[8];							//eFUSE-ID
		unsigned char	UID[16];							//UID
	}EMMCID[80];		 
}tyGetEMMCID;  


#endif


