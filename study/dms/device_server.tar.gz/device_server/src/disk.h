/*****************************************************************************
 * Copyright (C) 2018-2019
 * file:    disk.h
 * author:  liuxiaolong <383368144@qq.com>
 * created: 2019-04-25  
 * updated: 2019-04-25 
 *****************************************************************************/

#ifndef DISK_H
#define DISK_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>

#define USB_BUS 1
#define CAN_BUS 0

#define M3720   1
#define MX6Q    2

#define HARD_PLATFORM       M3720

#define LS427   1
#define LS701   2
#define LS726   3

#define TEST_MACHINE        LS427

#define USB_DEV_COUNT       40
#define CAN_DEV_COUNT       40

#define CAN_GET_STATUS "00get dut status\r"
#define CAN_RW_LEN          512

#define MNT_PATH "/tmp/mnt"
#define DRIVE_FILE "driver.txt"

typedef struct usb_port_map {
    
    char usb_path[32];
    char dev_name[10];

} usb_port_map;

typedef struct cfg_desc
{
    int usb_bus;
    int can_bus;
    int hard_plat;
    int test_machine;

} cfg_desc;

typedef struct can_disk_buff_map
{
    int data_len;
    char buff[512];
    int data_ready;
} can_disk_buff_map;


extern usb_port_map usb_port_map_list[41];
extern int can_port_map_list[80];
extern can_disk_buff_map can_disk_buff_map_list[81];

int disk_read(char *read_buf,int length, int id);
int disk_write(char *write_buf, int length, int id);
int disk_write_read(char *write_buf, int length, int id);
int update_disk_read(char *read_buf,int length, int id, char *com_file);
int update_disk_write(char *write_buf, int length, int id, char *com_file);
int update_disk_file(char *path,int id);
int disk_read_timeout(char *read_buff,int length, int id);
int can_disk_read(char *read_buf,int length);
int can_disk_write(char *write_buf, int length);

#ifdef __cplusplus
}
#endif
#endif
