#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    fputs("Hello World! 1\n", stdout);
    fputs("Hello World! 2\n", stdout);
    exit(0);
}