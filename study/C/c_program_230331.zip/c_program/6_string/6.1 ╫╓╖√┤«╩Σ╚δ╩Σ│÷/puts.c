#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
    char str[50]="Linux app puts test";

    puts("Hello world");
    puts(str);

    exit(0);
}