#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    char str[100];

    bzero(str,sizeof(str));
    
    exit(0);
}