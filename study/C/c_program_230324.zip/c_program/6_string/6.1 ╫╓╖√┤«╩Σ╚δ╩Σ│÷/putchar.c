#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    putchar('A');
    putchar('B');
    putchar('C');
    putchar('D');
    putchar('\n');
    putchar('A');
    putchar('B');
    putchar('C');
    putchar('D');
    putchar('\n');

    exit(0);
}